/*
 * animation.cpp - two-lane traffic (left -> right)
 *
 * FRONT lane: cars always flow when signal is G/Y (no stop-sign halt)
 * INNER lane: queue at stop sign — horn 1s + door, then 50% path in 1.5s;
 *             new inner car spawns when the stopped car pulls away
 *
 * RED -> all lanes hold (except cars already in stop sequence)
 */

#ifdef __APPLE__
#define GL_SILENCE_DEPRECATION
#include <GLUT/glut.h>
#else
#include <GL/glut.h>
#endif

#include "animation.h"
#include "sound.h"

#define CAR_STATE_MOVE   0
#define CAR_STATE_STOP   1
#define CAR_STATE_ACCEL  2

typedef struct {
    int   active;
    int   lane;
    int   state;
    int   stateTimerMs;
    float x;
    float y;
    float w;
    float bodyR;
    float bodyG;
    float bodyB;
    float doorOpen;
    float accelStartX;
    float accelTargetX;
} CarAnim;

static int     gLightState = ANIM_LIGHT_RED;
static int     gHornActive = 0;
static int     gPaused     = 0;
static int     gInnerSpawnTimerMs = 1500;
static CarAnim gCars[ANIM_MAX_CARS];

static const float LANE_FRONT_Y    = -0.645f;
static const float LANE_INNER_Y    = -0.495f;
static const float CAR_SLOW_SPEED  = 0.003f;
static const float CAR_FAST_SPEED  = 0.010f;
static const float CAR_WRAP_RIGHT  =  1.15f;
static const float CAR_WRAP_LEFT   = -1.15f;
static const float STOP_ZONE_HALF  =  0.09f;
static const int   INNER_STOP_MS   = 1000;
static const int   INNER_ACCEL_MS  = 1500;
static const int   INNER_SPAWN_MS  = 1500;
static const int   ANIM_TIMER_MS   = 16;
static const int   NUM_FRONT_CARS  = 4;
static const int   NUM_INNER_SLOTS = 4;

static void initCarSlot(int i, int lane, float x, float y, float w,
                        float r, float g, float b)
{
    gCars[i].active        = 1;
    gCars[i].lane          = lane;
    gCars[i].state         = CAR_STATE_MOVE;
    gCars[i].stateTimerMs  = 0;
    gCars[i].x             = x;
    gCars[i].y             = y;
    gCars[i].w             = w;
    gCars[i].bodyR         = r;
    gCars[i].bodyG         = g;
    gCars[i].bodyB         = b;
    gCars[i].doorOpen      = 0.0f;
    gCars[i].accelStartX   = x;
    gCars[i].accelTargetX  = x;
}

static float carCenterX(int i)
{
    return gCars[i].x + gCars[i].w * 0.5f;
}

static int carInStopZone(int i)
{
    float c = carCenterX(i);
    return (c >= ANIM_STOP_SIGN_X - STOP_ZONE_HALF &&
            c <= ANIM_STOP_SIGN_X + STOP_ZONE_HALF);
}

static float laneSpeed(void)
{
    if (gLightState == ANIM_LIGHT_GREEN)
        return CAR_FAST_SPEED;
    if (gLightState == ANIM_LIGHT_YELLOW)
        return CAR_SLOW_SPEED;
    return 0.0f;
}

static int findFreeInnerSlot(void)
{
    int i;
    for (i = NUM_FRONT_CARS; i < NUM_FRONT_CARS + NUM_INNER_SLOTS; i++) {
        if (!gCars[i].active)
            return i;
    }
    return -1;
}

static void spawnInnerCar(void)
{
    static const float colors[4][3] = {
        { 0.15f, 0.35f, 0.85f },
        { 0.20f, 0.65f, 0.25f },
        { 0.90f, 0.55f, 0.10f },
        { 0.55f, 0.10f, 0.45f }
    };
    int slot = findFreeInnerSlot();
    int ci;

    if (slot < 0)
        return;

    ci = slot - NUM_FRONT_CARS;
    initCarSlot(slot, ANIM_LANE_INNER, CAR_WRAP_LEFT,
                LANE_INNER_Y, 0.17f + (float)(ci % 2) * 0.02f,
                colors[ci][0], colors[ci][1], colors[ci][2]);
}

static void updateDoor(int i)
{
    if (gCars[i].state == CAR_STATE_STOP) {
        gCars[i].doorOpen += 0.12f;
        if (gCars[i].doorOpen > 1.0f)
            gCars[i].doorOpen = 1.0f;
    } else {
        gCars[i].doorOpen -= 0.10f;
        if (gCars[i].doorOpen < 0.0f)
            gCars[i].doorOpen = 0.0f;
    }
}

static void beginInnerStop(int i)
{
    float halfPath;

    gCars[i].state        = CAR_STATE_STOP;
    gCars[i].stateTimerMs = INNER_STOP_MS;
    halfPath = (CAR_WRAP_RIGHT - ANIM_STOP_SIGN_X) * 0.5f;
    gCars[i].accelStartX  = gCars[i].x;
    gCars[i].accelTargetX = ANIM_STOP_SIGN_X + halfPath - gCars[i].w * 0.5f;
}

static void beginInnerAccel(int i)
{
    gCars[i].state        = CAR_STATE_ACCEL;
    gCars[i].stateTimerMs = INNER_ACCEL_MS;
    gCars[i].accelStartX  = gCars[i].x;
    spawnInnerCar();
}

static void updateFrontCar(int i, int *movingAny)
{
    float speed = laneSpeed();

    updateDoor(i);

    /* front lane always flows (slow crawl even on red) */
    if (speed <= 0.0f)
        speed = CAR_SLOW_SPEED * 0.6f;

    gCars[i].x += speed;
    *movingAny = 1;

    if (gCars[i].x > CAR_WRAP_RIGHT)
        gCars[i].x = CAR_WRAP_LEFT - gCars[i].w * (float)(i * 0.22f);
}

static void updateInnerCar(int i, int *hornAny, int *movingAny)
{
    float speed;
    float t;
    float newX;

    updateDoor(i);

    if (gCars[i].state == CAR_STATE_STOP) {
        *hornAny = 1;
        gCars[i].stateTimerMs -= ANIM_TIMER_MS;
        if (gCars[i].stateTimerMs <= 0)
            beginInnerAccel(i);
        return;
    }

    if (gCars[i].state == CAR_STATE_ACCEL) {
        t = 1.0f - (float)gCars[i].stateTimerMs / (float)INNER_ACCEL_MS;
        if (t < 0.0f) t = 0.0f;
        if (t > 1.0f) t = 1.0f;
        newX = gCars[i].accelStartX +
               (gCars[i].accelTargetX - gCars[i].accelStartX) * t;
        if (newX > gCars[i].x) {
            gCars[i].x = newX;
            *movingAny = 1;
        }
        gCars[i].stateTimerMs -= ANIM_TIMER_MS;
        if (gCars[i].stateTimerMs <= 0)
            gCars[i].state = CAR_STATE_MOVE;
        return;
    }

    speed = laneSpeed();
    if (speed <= 0.0f)
        return;

    if (carInStopZone(i)) {
        beginInnerStop(i);
        *hornAny = 1;
        return;
    }

    gCars[i].x += speed;
    *movingAny = 1;

    if (gCars[i].x > CAR_WRAP_RIGHT)
        gCars[i].active = 0;
}

void animationInit(void)
{
    int i;

    gLightState       = ANIM_LIGHT_RED;
    gHornActive       = 0;
    gInnerSpawnTimerMs = INNER_SPAWN_MS;
    soundInit();

    for (i = 0; i < ANIM_MAX_CARS; i++)
        gCars[i].active = 0;

    initCarSlot(0, ANIM_LANE_FRONT, -1.05f, LANE_FRONT_Y, 0.18f, 0.85f, 0.08f, 0.08f);
    initCarSlot(1, ANIM_LANE_FRONT, -0.72f, LANE_FRONT_Y, 0.20f, 0.60f, 0.62f, 0.65f);
    initCarSlot(2, ANIM_LANE_FRONT, -0.38f, LANE_FRONT_Y, 0.17f, 0.15f, 0.35f, 0.85f);
    initCarSlot(3, ANIM_LANE_FRONT, -0.05f, LANE_FRONT_Y, 0.19f, 0.90f, 0.55f, 0.10f);
}

void animationStart(void)
{
    glutTimerFunc(ANIM_TIMER_MS, animationTimer, 0);
}

void animationTimer(int value)
{
    int i;
    int hornAny = 0;
    int movingAny = 0;
    int hasInner = 0;

    (void)value;

    if (gPaused) {
        glutPostRedisplay();
        glutTimerFunc(ANIM_TIMER_MS, animationTimer, 0);
        return;
    }

    for (i = NUM_FRONT_CARS; i < NUM_FRONT_CARS + NUM_INNER_SLOTS; i++) {
        if (gCars[i].active)
            hasInner = 1;
    }

    if (!hasInner) {
        gInnerSpawnTimerMs -= ANIM_TIMER_MS;
        if (gInnerSpawnTimerMs <= 0) {
            spawnInnerCar();
            gInnerSpawnTimerMs = INNER_SPAWN_MS;
        }
    }

    for (i = 0; i < ANIM_MAX_CARS; i++) {
        if (!gCars[i].active)
            continue;

        if (gCars[i].lane == ANIM_LANE_FRONT)
            updateFrontCar(i, &movingAny);
        else
            updateInnerCar(i, &hornAny, &movingAny);
    }

    gHornActive = hornAny;
    soundUpdate(gHornActive, movingAny);

    glutPostRedisplay();
    glutTimerFunc(ANIM_TIMER_MS, animationTimer, 0);
}

int animationGetLightState(void)
{
    return gLightState;
}

void animationSetLightState(int state)
{
    if (state < ANIM_LIGHT_RED || state > ANIM_LIGHT_YELLOW)
        return;
    gLightState = state;
}

int animationGetCarCount(void)
{
    return ANIM_MAX_CARS;
}

int animationIsCarActive(int index)
{
    if (index < 0 || index >= ANIM_MAX_CARS)
        return 0;
    return gCars[index].active;
}

void animationGetCar(int index, float *x, float *y, float *w,
                     float *bodyR, float *bodyG, float *bodyB)
{
    if (index < 0 || index >= ANIM_MAX_CARS)
        return;
    if (x)     *x     = gCars[index].x;
    if (y)     *y     = gCars[index].y;
    if (w)     *w     = gCars[index].w;
    if (bodyR) *bodyR = gCars[index].bodyR;
    if (bodyG) *bodyG = gCars[index].bodyG;
    if (bodyB) *bodyB = gCars[index].bodyB;
}

float animationGetCarDoorOpen(int index)
{
    if (index < 0 || index >= ANIM_MAX_CARS || !gCars[index].active)
        return 0.0f;
    return gCars[index].doorOpen;
}

int animationIsHornActive(void)
{
    return gHornActive;
}

void animationTogglePause(void)
{
    gPaused = !gPaused;
}

int animationIsPaused(void)
{
    return gPaused;
}
