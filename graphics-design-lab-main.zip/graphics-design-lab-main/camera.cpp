/*
 * camera.cpp - orbit camera for 3D scene inspection
 *
 * CONTROLS:
 *   Left/Right arrow - rotate around scene (yaw)
 *   Up/Down arrow    - tilt camera (pitch)
 *   +/- keys         - zoom in / out
 *   0 key            - reset camera
 */

#ifdef __APPLE__
#define GL_SILENCE_DEPRECATION
#include <OpenGL/gl.h>
#include <OpenGL/glu.h>
#include <GLUT/glut.h>
#else
#include <GL/gl.h>
#include <GL/glu.h>
#include <GL/glut.h>
#endif

#include <math.h>
#include "camera.h"

#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif

static int   gWinW = 1000;
static int   gWinH = 650;

static float gCamYaw   = 0.0f;
static float gCamPitch = 8.0f;
static float gCamDist  = 43.0f;
static float gCamTargetX = 0.0f;
static float gCamTargetY = 9.0f;
static float gCamTargetZ = -3.0f;

static const float CAM_FOV    = 45.0;
static const float CAM_NEAR   = 0.1f;
static const float CAM_FAR    = 250.0f;
static const float CAM_YAW_STEP   = 5.0f;
static const float CAM_PITCH_STEP = 3.0f;
static const float CAM_PITCH_MAX  = 85.0f;
static const float CAM_PITCH_MIN  = -15.0f;
static const float CAM_DIST_MIN   = 18.0f;
static const float CAM_DIST_MAX   = 75.0f;
static const float CAM_ZOOM_STEP  =  3.0f;

void cameraInit(void)
{
    gWinW = 1000;
    gWinH = 650;
    gCamYaw   = 0.0f;
    gCamPitch = 8.0f;
    gCamDist  = 43.0f;
    gCamTargetX = 0.0f;
    gCamTargetY = 9.0f;
    gCamTargetZ = -3.0f;
}

void cameraApply(void)
{
    float yawR, pitchR, cp, eyeX, eyeY, eyeZ;

    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluPerspective(CAM_FOV, (double)gWinW / (double)gWinH, CAM_NEAR, CAM_FAR);

    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();

    yawR   = gCamYaw * (float)M_PI / 180.0f;
    pitchR = gCamPitch * (float)M_PI / 180.0f;
    cp     = (float)cos(pitchR);

    eyeX = gCamTargetX + gCamDist * (float)sin(yawR) * cp;
    eyeY = gCamTargetY + gCamDist * (float)sin(pitchR);
    eyeZ = gCamTargetZ + gCamDist * (float)cos(yawR) * cp;

    gluLookAt(eyeX, eyeY, eyeZ,
              gCamTargetX, gCamTargetY, gCamTargetZ,
              0.0, 1.0, 0.0);
}

void cameraApplyHUD(void)
{
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluOrtho2D(-1.0, 1.0, -1.0, 1.0);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
}

void cameraReshape(int w, int h)
{
    if (h == 0) h = 1;
    gWinW = w;
    gWinH = h;
    glViewport(0, 0, w, h);
    glutPostRedisplay();
}

void cameraSpecialKeys(int key, int x, int y)
{
    (void)x;
    (void)y;

    switch (key) {
        case GLUT_KEY_LEFT:
            gCamYaw -= CAM_YAW_STEP;
            break;
        case GLUT_KEY_RIGHT:
            gCamYaw += CAM_YAW_STEP;
            break;
        case GLUT_KEY_UP:
            gCamPitch += CAM_PITCH_STEP;
            if (gCamPitch > CAM_PITCH_MAX) gCamPitch = CAM_PITCH_MAX;
            break;
        case GLUT_KEY_DOWN:
            gCamPitch -= CAM_PITCH_STEP;
            if (gCamPitch < CAM_PITCH_MIN) gCamPitch = CAM_PITCH_MIN;
            break;
        default:
            break;
    }
    glutPostRedisplay();
}

void cameraZoomIn(void)
{
    gCamDist -= CAM_ZOOM_STEP;
    if (gCamDist < CAM_DIST_MIN) gCamDist = CAM_DIST_MIN;
    glutPostRedisplay();
}

void cameraZoomOut(void)
{
    gCamDist += CAM_ZOOM_STEP;
    if (gCamDist > CAM_DIST_MAX) gCamDist = CAM_DIST_MAX;
    glutPostRedisplay();
}

void cameraReset(void)
{
    gCamYaw   = 0.0f;
    gCamPitch = 8.0f;
    gCamDist  = 43.0f;
    glutPostRedisplay();
}
