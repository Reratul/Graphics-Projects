/*
 * scene.h - 3D traffic scene rendering (buildings, road, cars, HUD)
 */

#ifndef SCENE_H
#define SCENE_H

#ifdef __cplusplus
extern "C" {
#endif

void sceneInit(void);
void sceneDraw(void);
void sceneToggleNight(void);
void sceneSetNightMode(int nightOn);
int  sceneIsNightMode(void);
void sceneToggleHelp(void);
int  sceneIsHelpVisible(void);

#ifdef __cplusplus
}
#endif

#endif /* SCENE_H */
