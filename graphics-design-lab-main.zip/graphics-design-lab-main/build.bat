@echo off
REM Windows MinGW build script for Traffic Signal Scene
g++ -Wall -Wextra main.cpp scene.cpp camera.cpp animation.cpp sound.cpp input.cpp config.cpp export.cpp lighting.cpp -o TrafficScene.exe -lfreeglut -lopengl32 -lglu32
if %ERRORLEVEL% EQU 0 (
    echo Build OK: TrafficScene.exe
) else (
    echo Build FAILED
    exit /b 1
)
