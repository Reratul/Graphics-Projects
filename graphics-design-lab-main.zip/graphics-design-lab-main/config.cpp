/*
 * config.cpp - parse CLI args before glutInit
 *
 * Usage:
 *   TrafficScene [options]
 *   --help              show help
 *   --night             start at night
 *   --day               start at day
 *   --size W H          window size (default 1000 650)
 *   --mute              start with sound off
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "config.h"

static int gWidth  = 1000;
static int gHeight = 650;
static int gStartNight = -1;
static int gSoundOff   = 0;

void configPrintUsage(const char *prog)
{
    printf("Traffic Signal Scene - OpenGL/GLUT\n\n");
    printf("Usage: %s [options]\n\n", prog ? prog : "TrafficScene");
    printf("Options:\n");
    printf("  -h, --help       Show this help\n");
    printf("  --night          Start in night mode\n");
    printf("  --day            Start in day mode\n");
    printf("  --size W H       Window width and height (default 1000 650)\n");
    printf("  --mute           Start with sound muted\n");
    printf("\nIn-app keys: R/G/Y signal  N night  Arrows camera  +/- zoom\n");
    printf("             0 reset cam  M mute  P pause  S screenshot  F fullscreen\n");
    printf("             H help  ESC quit\n");
}

void configParseArgs(int *argc, char **argv)
{
    int i, out;

    if (!argc || !argv) return;

    out = 1;
    for (i = 1; i < *argc; ) {
        if (strcmp(argv[i], "-h") == 0 || strcmp(argv[i], "--help") == 0) {
            configPrintUsage(argv[0]);
            exit(0);
        }
        if (strcmp(argv[i], "--night") == 0) {
            gStartNight = 1;
            i++;
            continue;
        }
        if (strcmp(argv[i], "--day") == 0) {
            gStartNight = 0;
            i++;
            continue;
        }
        if (strcmp(argv[i], "--mute") == 0) {
            gSoundOff = 1;
            i++;
            continue;
        }
        if (strcmp(argv[i], "--size") == 0 && i + 2 < *argc) {
            gWidth  = atoi(argv[i + 1]);
            gHeight = atoi(argv[i + 2]);
            if (gWidth < 400)  gWidth  = 400;
            if (gHeight < 300) gHeight = 300;
            i += 3;
            continue;
        }
        argv[out++] = argv[i++];
    }
    *argc = out;
    argv[out] = NULL;
}

int configGetWidth(void)  { return gWidth; }
int configGetHeight(void) { return gHeight; }
int configGetStartNight(void) { return gStartNight; }
int configGetStartSoundOff(void) { return gSoundOff; }
