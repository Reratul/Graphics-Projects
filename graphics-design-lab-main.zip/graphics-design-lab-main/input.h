/*
 * input.h - keyboard command parser (all controls in one place)
 */

#ifndef INPUT_H
#define INPUT_H

#ifdef __cplusplus
extern "C" {
#endif

void inputKeyboard(unsigned char key, int x, int y);
void inputSpecial(int key, int x, int y);

#ifdef __cplusplus
}
#endif

#endif /* INPUT_H */
