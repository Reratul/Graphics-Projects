/*
 * animation.h - two-lane traffic, stop-sign queue on inner lane
 */

#ifndef ANIMATION_H
#define ANIMATION_H

#ifdef __cplusplus
extern "C" {
#endif

#define ANIM_LIGHT_RED    0
#define ANIM_LIGHT_GREEN  1
#define ANIM_LIGHT_YELLOW 2

#define ANIM_MAX_CARS     8
#define ANIM_LANE_FRONT   0
#define ANIM_LANE_INNER   1
#define ANIM_STOP_SIGN_X  0.18f

void animationInit(void);
void animationStart(void);
void animationTimer(int value);

int  animationGetLightState(void);
void animationSetLightState(int state);

int  animationGetCarCount(void);
int  animationIsCarActive(int index);
void animationGetCar(int index, float *x, float *y, float *w,
                     float *bodyR, float *bodyG, float *bodyB);
float animationGetCarDoorOpen(int index);
int   animationIsHornActive(void);

void  animationTogglePause(void);
int   animationIsPaused(void);

#ifdef __cplusplus
}
#endif

#endif /* ANIMATION_H */
