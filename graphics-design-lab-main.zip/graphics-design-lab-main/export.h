/*
 * export.h - screenshot capture and fullscreen toggle
 */

#ifndef EXPORT_H
#define EXPORT_H

#ifdef __cplusplus
extern "C" {
#endif

void exportInit(int width, int height);
void exportRequestScreenshot(void);
void exportCaptureIfRequested(void);
void exportToggleFullscreen(void);
int  exportIsFullscreen(void);
const char *exportGetStatusMessage(void);
void exportTickMessage(void);

#ifdef __cplusplus
}
#endif

#endif /* EXPORT_H */
