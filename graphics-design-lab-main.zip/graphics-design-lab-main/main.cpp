// -------------------main.cpp---------------
/*
 ******************************************************************
 *  Traffic Signal Scene - Step 11 (3D depth + lighting)
 *
 *  BUILD:  make  |  build.bat  |  TrafficScene.cbp
 *
 *  CLI:  ./TrafficScene --help
 *        ./TrafficScene --night --size 1200 800
 ******************************************************************
 */

#ifdef __APPLE__
#define GL_SILENCE_DEPRECATION
#include <GLUT/glut.h>
#else
#include <GL/glut.h>
#endif

#include "config.h"
#include "camera.h"
#include "animation.h"
#include "scene.h"
#include "sound.h"
#include "input.h"
#include "export.h"

int main(int argc, char **argv)
{
    configParseArgs(&argc, argv);

    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);
    glutInitWindowSize(configGetWidth(), configGetHeight());
    glutInitWindowPosition(60, 40);
    glutCreateWindow("Traffic Signal Scene 3D | H=Help | ESC=Quit");

    glEnable(GL_DEPTH_TEST);
    glEnable(GL_CULL_FACE);
    glCullFace(GL_BACK);

    exportInit(configGetWidth(), configGetHeight());

    cameraInit();
    sceneInit();
    animationInit();

    if (configGetStartNight() >= 0)
        sceneSetNightMode(configGetStartNight());
    if (configGetStartSoundOff())
        soundSetEnabled(0);

    glutDisplayFunc(sceneDraw);
    glutReshapeFunc(cameraReshape);
    glutKeyboardFunc(inputKeyboard);
    glutSpecialFunc(inputSpecial);
    animationStart();

    glutMainLoop();
    return 0;
}
