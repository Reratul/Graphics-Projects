/*
 * input.cpp - parse keyboard and route to camera / animation / scene / sound
 *
 * CONTROLS:
 *   R G Y     traffic signal
 *   N         night / day
 *   Arrows    camera rotate
 *   + -       zoom in / out
 *   0         reset camera
 *   M         mute / unmute sound
 *   H         help overlay on / off
 *   P         pause / resume animation
 *   S         save screenshot (PPM)
 *   F         fullscreen on / off
 *   ESC       quit
 */

#ifdef __APPLE__
#define GL_SILENCE_DEPRECATION
#include <GLUT/glut.h>
#else
#include <GL/glut.h>
#endif

#include <stdlib.h>
#include "input.h"
#include "camera.h"
#include "animation.h"
#include "scene.h"
#include "sound.h"
#include "export.h"

void inputKeyboard(unsigned char key, int x, int y)
{
    (void)x;
    (void)y;

    switch (key) {
        case 'r': case 'R':
            animationSetLightState(ANIM_LIGHT_RED);
            break;
        case 'g': case 'G':
            animationSetLightState(ANIM_LIGHT_GREEN);
            break;
        case 'y': case 'Y':
            animationSetLightState(ANIM_LIGHT_YELLOW);
            break;
        case 'n': case 'N':
            sceneToggleNight();
            break;
        case '+': case '=':
            cameraZoomIn();
            break;
        case '-': case '_':
            cameraZoomOut();
            break;
        case '0':
            cameraReset();
            break;
        case 'm': case 'M':
            soundSetEnabled(!soundIsEnabled());
            break;
        case 'h': case 'H':
            sceneToggleHelp();
            break;
        case 'p': case 'P':
            animationTogglePause();
            break;
        case 's': case 'S':
            exportRequestScreenshot();
            break;
        case 'f': case 'F':
            exportToggleFullscreen();
            break;
        case 27:
            exit(0);
            break;
        default:
            break;
    }
    glutPostRedisplay();
}

void inputSpecial(int key, int x, int y)
{
    cameraSpecialKeys(key, x, y);
}
