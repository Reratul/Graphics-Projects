/*
 * sound.cpp - horn buzzer + engine hum while cars move
 */

#include <stdio.h>
#include "sound.h"

#ifdef _WIN32
#include <windows.h>
#endif

#ifdef __APPLE__
#include <AudioToolbox/AudioToolbox.h>
#endif

static int gFrame = 0;
static int gSoundOn = 1;

void soundInit(void)
{
    gFrame = 0;
    gSoundOn = 1;
}

static void playHornBeep(void)
{
#ifdef _WIN32
    Beep(880, 90);
#elif defined(__APPLE__)
    AudioServicesPlaySystemSound(1007);
#else
    printf("\a");
    fflush(stdout);
#endif
}

static void playEngineTick(void)
{
#ifdef _WIN32
    Beep(120, 25);
#elif defined(__APPLE__)
    /* subtle low tick - system pop sound, kept quiet */
    AudioServicesPlaySystemSound(1104);
#else
    /* no-op on unknown platforms */
    (void)0;
#endif
}

void soundUpdate(int hornActive, int carsMoving)
{
    if (!gSoundOn)
        return;

    gFrame++;

    if (hornActive && (gFrame % 10) == 0)
        playHornBeep();

    if (carsMoving && !hornActive && (gFrame % 28) == 0)
        playEngineTick();
}

void soundSetEnabled(int enabled)
{
    gSoundOn = enabled ? 1 : 0;
}

int soundIsEnabled(void)
{
    return gSoundOn;
}
