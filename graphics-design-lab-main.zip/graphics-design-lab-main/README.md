# Traffic Signal Scene (OpenGL / GLUT)

3D traffic scene in C/C++ with GLUT and OpenGL. Buildings are full 3D boxes; cars, road, trees, and signs keep the original 2D design on the road plane. Includes keyboard traffic control, stop-sign behaviour, sound, camera orbit, and CLI options.

## Features

- 3D buildings with original colors, yellow windows, and brown doors
- 8 animated cars on the street
- Traffic signal: **R** stop, **Y** slow, **G** fast
- Stop sign: door opens, car stops 3 seconds, horn buzzes
- Engine ticks while moving; horn at stop sign
- OpenGL lighting on 3D buildings (normals, sun/moon, window glow at night)
- Day / night toggle
- 3D camera: arrow keys, zoom, reset
- Help overlay, pause, sound mute
- Command-line startup options

## Project structure

```
graphy/
├── main.cpp          GLUT init and main loop
├── scene.h/cpp       Drawing (sky, buildings, road, cars, HUD)
├── camera.h/cpp      gluPerspective, gluLookAt, orbit camera
├── animation.h/cpp   Cars, traffic light, stop-sign logic
├── sound.h/cpp       Horn and engine (macOS AudioToolbox / Windows Beep)
├── input.h/cpp       Keyboard routing
├── config.h/cpp      CLI argument parser
├── export.h/cpp      Screenshot (PPM) and fullscreen toggle
├── lighting.h/cpp    OpenGL lighting for 3D building depth (day/night)
├── Makefile          macOS / Linux build
├── build.bat         Windows MinGW build
└── TrafficScene.cbp  Code::Blocks project
```

## Build and run

### macOS

```bash
make
./TrafficScene
# or
make run
```

Manual compile:

```bash
g++ main.cpp scene.cpp camera.cpp animation.cpp sound.cpp input.cpp config.cpp export.cpp lighting.cpp \
  -o TrafficScene -framework OpenGL -framework GLUT -framework AudioToolbox
./TrafficScene
```

### Linux

```bash
make
./TrafficScene
```

Requires GLUT (`freeglut` or `glut` package).

### Windows (MinGW)

```bat
build.bat
TrafficScene.exe
```

### Code::Blocks

Open `TrafficScene.cbp`, add all `.cpp` files if needed, and link:

- `freeglut`
- `opengl32`
- `glu32`

## Command-line options

```bash
./TrafficScene --help
./TrafficScene --night
./TrafficScene --day --size 1200 800
./TrafficScene --mute
```

| Option | Description |
|--------|-------------|
| `-h`, `--help` | Print usage and exit |
| `--night` | Start in night mode |
| `--day` | Start in day mode |
| `--size W H` | Window size (default 1000×650) |
| `--mute` | Start with sound off |

## Controls

| Key | Action |
|-----|--------|
| **R** | Red signal — cars stop |
| **G** | Green signal — cars move fast |
| **Y** | Yellow signal — cars move slow |
| **N** | Toggle night / day |
| **← → ↑ ↓** | Rotate camera |
| **+** / **-** | Zoom in / out |
| **0** | Reset camera |
| **M** | Mute / unmute sound |
| **P** | Pause / resume animation |
| **S** | Save screenshot (`traffic_scene_0001.ppm`) |
| **F** | Toggle fullscreen |
| **H** | Show / hide help overlay |
| **ESC** | Quit |

Screenshots are saved as PPM in the project folder. Open in Preview (macOS) or convert with any image tool.

## Module overview

| Module | Role |
|--------|------|
| `scene` | Renders sky, stars, moon, 3D buildings, road, trees, traffic lights, stop sign, cars, HUD |
| `camera` | Perspective projection, `gluLookAt`, arrow-key orbit, zoom, reset |
| `animation` | 8 cars, signal state, stop-zone logic, door animation, horn trigger |
| `sound` | Engine hum and horn beeps (respects mute) |
| `input` | Central keyboard handler |
| `config` | Parses CLI args before `glutInit` |

## Assignment checklist

- [x] 2D design preserved (colors, windows, doors, car art)
- [x] 3D buildings with depth
- [x] `gluLookAt` + arrow-key 3D inspection
- [x] R / Y / G traffic control
- [x] Many cars on the street
- [x] Stop sign: door, 3 s stop, horn
- [x] Car movement sound
- [x] Separate source files (scene, camera, animation, sound, input, config)
- [x] Code::Blocks project + Makefile

## License

Educational / coursework project.
