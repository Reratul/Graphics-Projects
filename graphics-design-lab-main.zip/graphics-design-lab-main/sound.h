/*
 * sound.h - engine & horn sounds (Step 4)
 */

#ifndef SOUND_H
#define SOUND_H

#ifdef __cplusplus
extern "C" {
#endif

void soundInit(void);
void soundUpdate(int hornActive, int carsMoving);
void soundSetEnabled(int enabled);
int  soundIsEnabled(void);

#ifdef __cplusplus
}
#endif

#endif /* SOUND_H */
