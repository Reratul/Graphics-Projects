/*
 * scene.cpp - 3D traffic scene (buildings, road, sky, cars, HUD)
 */

#ifdef __APPLE__
#define GL_SILENCE_DEPRECATION
#include <OpenGL/gl.h>
#include <GLUT/glut.h>
#else
#include <GL/gl.h>
#include <GL/glut.h>
#endif

#include <math.h>
#include "scene.h"
#include "camera.h"
#include "animation.h"
#include "sound.h"
 #include "export.h"
 #include "lighting.h"

#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif

static int gNightMode = 1;
static int gHelpVisible = 0;

static void applySceneBackground(void)
{
    if (gNightMode)
        glClearColor(0.06f, 0.06f, 0.07f, 1.0f);
    else
        glClearColor(0.93f, 0.91f, 0.88f, 1.0f);
}

 /* 3D scene scale: maps original 2D coords (-1..1) into world units */
 const float SCENE_SCALE        = 25.0f;
 const float ROAD_2D_Y          = -0.72f;
 const float BUILDING_DEPTH_MUL = 0.38f;  /* depth relative to building width */
 const float BUILDING_ROW_Z     = -7.5f;

 /* Full-width scene span (slight bleed past -1..1 so edges fill the view) */
 const float SCENE_X_LEFT   = -1.08f;
 const float SCENE_X_WIDTH  =  2.16f;

 static float mapX2D(float x2d) { return x2d * SCENE_SCALE; }
 static float mapY2D(float y2d) { return (y2d - ROAD_2D_Y) * SCENE_SCALE; }

 /* Place original 2D drawing (-1..1 coords) onto the 3D road plane */
 void pushOriginal2D(float zPlane)
 {
     glPushMatrix();
     glDisable(GL_CULL_FACE);
     glTranslatef(0.0f, 0.0f, zPlane);
     glScalef(SCENE_SCALE, SCENE_SCALE, 1.0f);
     glTranslatef(0.0f, -ROAD_2D_Y, 0.0f);
 }

 void popOriginal2D(void)
 {
     glEnable(GL_CULL_FACE);
     glPopMatrix();
 }
 
 /* ============================================================
    FILLED Rectangle
    ============================================================ */
 void fillRect(float x, float y, float w, float h)
 {
     glBegin(GL_QUADS);
         glVertex2f(x,     y);
         glVertex2f(x + w, y);
         glVertex2f(x + w, y + h);
         glVertex2f(x,     y + h);
     glEnd();
 }
 
 /* ============================================================
    OUTLINE Rectangle (black border over fill)
    ============================================================ */
 void outlineRect(float x, float y, float w, float h)
 {
     glBegin(GL_LINE_LOOP);
         glVertex2f(x,     y);
         glVertex2f(x + w, y);
         glVertex2f(x + w, y + h);
         glVertex2f(x,     y + h);
     glEnd();
 }
 
 /* ============================================================
    FILLED Circle
    ============================================================ */
 void fillCircle(float cx, float cy, float r, int segs)
 {
     int i;
     float a;
     glBegin(GL_TRIANGLE_FAN);
         glVertex2f(cx, cy);
         for (i = 0; i <= segs; i++) {
             a = (float)(2.0 * M_PI * i / segs);
             glVertex2f(cx + r * (float)cos(a),
                        cy + r * (float)sin(a));
         }
     glEnd();
 }
 
 /* ============================================================
    OUTLINE Circle
    ============================================================ */
 void outlineCircle(float cx, float cy, float r, int segs)
 {
     int i;
     float a;
     glBegin(GL_LINE_LOOP);
         for (i = 0; i < segs; i++) {
             a = (float)(2.0 * M_PI * i / segs);
             glVertex2f(cx + r * (float)cos(a),
                        cy + r * (float)sin(a));
         }
     glEnd();
 }

 /* One traffic-signal lamp: inactive = dark gray, active = solid bright color */
 static void drawSignalLamp(float cx, float cy, float r, int active,
                            float ar, float ag, float ab)
 {
     glColor3f(0.04f, 0.04f, 0.04f);
     fillCircle(cx, cy, r + 0.002f, 48);

     if (active) {
         glColor3f(ar, ag, ab);
         fillCircle(cx, cy, r * 0.90f, 48);
     } else {
         glColor3f(0.10f, 0.10f, 0.10f);
         fillCircle(cx, cy, r * 0.72f, 40);
     }

     glColor3f(0.18f, 0.18f, 0.18f);
     outlineCircle(cx, cy, r + 0.002f, 48);
 }

 /* ============================================================
    3D helpers (Step 1: building & scene depth)
    ============================================================ */
 void fillBox3D(float x, float y, float z, float w, float h, float d)
 {
     float x2 = x + w;
     float y2 = y + h;
     float z2 = z + d;

     glBegin(GL_QUADS);
         glVertex3f(x,  y,  z2); glVertex3f(x2, y,  z2);
         glVertex3f(x2, y2, z2); glVertex3f(x,  y2, z2);
         glVertex3f(x2, y,  z);  glVertex3f(x,  y,  z);
         glVertex3f(x,  y2, z);  glVertex3f(x2, y2, z);
         glVertex3f(x2, y,  z);  glVertex3f(x2, y,  z2);
         glVertex3f(x2, y2, z2); glVertex3f(x2, y2, z);
         glVertex3f(x,  y,  z2); glVertex3f(x,  y,  z);
         glVertex3f(x,  y2, z);  glVertex3f(x,  y2, z2);
         glVertex3f(x,  y2, z2); glVertex3f(x2, y2, z2);
         glVertex3f(x2, y2, z);  glVertex3f(x,  y2, z);
         glVertex3f(x,  y,  z);  glVertex3f(x2, y,  z);
         glVertex3f(x2, y,  z2); glVertex3f(x,  y,  z2);
     glEnd();
 }

 void outlineBox3D(float x, float y, float z, float w, float h, float d)
 {
     float x2 = x + w;
     float y2 = y + h;
     float z2 = z + d;

     glBegin(GL_LINE_LOOP);
         glVertex3f(x,  y,  z2); glVertex3f(x2, y,  z2);
         glVertex3f(x2, y2, z2); glVertex3f(x,  y2, z2);
     glEnd();
     glBegin(GL_LINE_LOOP);
         glVertex3f(x2, y,  z); glVertex3f(x,  y,  z);
         glVertex3f(x,  y2, z); glVertex3f(x2, y2, z);
     glEnd();
     glBegin(GL_LINE_LOOP);
         glVertex3f(x,  y,  z2); glVertex3f(x,  y,  z);
         glVertex3f(x,  y2, z); glVertex3f(x,  y2, z2);
     glEnd();
     glBegin(GL_LINE_LOOP);
         glVertex3f(x2, y,  z2); glVertex3f(x2, y,  z);
         glVertex3f(x2, y2, z); glVertex3f(x2, y2, z2);
     glEnd();
     glBegin(GL_LINE_LOOP);
         glVertex3f(x,  y2, z2); glVertex3f(x2, y2, z2);
         glVertex3f(x2, y2, z); glVertex3f(x,  y2, z);
     glEnd();
 }

 void fillQuad3D(float x1, float y1, float z1,
                 float x2, float y2, float z2,
                 float x3, float y3, float z3,
                 float x4, float y4, float z4)
 {
     glBegin(GL_QUADS);
         glVertex3f(x1, y1, z1);
         glVertex3f(x2, y2, z2);
         glVertex3f(x3, y3, z3);
         glVertex3f(x4, y4, z4);
     glEnd();
 }

 void fillQuad3D_n(float nx, float ny, float nz,
                   float x1, float y1, float z1,
                   float x2, float y2, float z2,
                   float x3, float y3, float z3,
                   float x4, float y4, float z4)
 {
     glNormal3f(nx, ny, nz);
     glBegin(GL_QUADS);
         glVertex3f(x1, y1, z1);
         glVertex3f(x2, y2, z2);
         glVertex3f(x3, y3, z3);
         glVertex3f(x4, y4, z4);
     glEnd();
 }

 void fillDisk3D(float cx, float cy, float cz, float r, int segs, int axis)
 {
     int i;
     float a, ca, sa;

     glBegin(GL_TRIANGLE_FAN);
     if (axis == 0) glVertex3f(cx, cy, cz);
     else if (axis == 1) glVertex3f(cx, cy, cz);
     else glVertex3f(cx, cy, cz);

     for (i = 0; i <= segs; i++) {
         a = (float)(2.0 * M_PI * i / segs);
         ca = (float)cos(a);
         sa = (float)sin(a);
         if (axis == 2)
             glVertex3f(cx + r * ca, cy + r * sa, cz);
         else if (axis == 1)
             glVertex3f(cx + r * ca, cy, cz + r * sa);
         else
             glVertex3f(cx, cy + r * ca, cz + r * sa);
     }
     glEnd();
 }

 /* ============================================================
    Background (solid light / dark — no sky blue, no extra panels)
    ============================================================ */
 void drawSky(void)
 {
     float zFar = -55.0f;
     float xL = mapX2D(SCENE_X_LEFT);
     float xR = mapX2D(SCENE_X_LEFT + SCENE_X_WIDTH);
     float yB =   0.0f;
     float yT =  45.0f;
     float br, bg, bb;

     if (gNightMode) {
         br = 0.06f; bg = 0.06f; bb = 0.07f;
     } else {
         br = 0.93f; bg = 0.91f; bb = 0.88f;
     }

     glDisable(GL_DEPTH_TEST);
     glColor3f(br, bg, bb);
     glBegin(GL_QUADS);
         glVertex3f(xL, yB, zFar);
         glVertex3f(xR, yB, zFar);
         glVertex3f(xR, yT, zFar);
         glVertex3f(xL, yT, zFar);
     glEnd();
     glEnable(GL_DEPTH_TEST);
 }
 
 /* ============================================================
    Stars
    ============================================================ */
 void drawStars(void)
 {
     int i;
     float stars[18][2] = {
         {-0.85f,0.88f},{-0.60f,0.93f},{-0.40f,0.78f},{-0.20f,0.95f},
         { 0.10f,0.87f},{ 0.30f,0.72f},{ 0.55f,0.91f},{ 0.75f,0.76f},
         { 0.90f,0.85f},{-0.72f,0.68f},{ 0.20f,0.80f},{-0.50f,0.58f},
         { 0.42f,0.65f},{-0.15f,0.70f},{ 0.68f,0.60f},{-0.30f,0.83f},
         { 0.82f,0.55f},{-0.62f,0.50f}
     };
     float zFar = -54.0f;

     glColor3f(1.0f, 1.0f, 0.85f);
     glPointSize(3.0f);
     glBegin(GL_POINTS);
     for (i = 0; i < 18; i++)
         glVertex3f(mapX2D(stars[i][0]), mapY2D(stars[i][1]) + 8.0f, zFar);
     glEnd();
     glPointSize(1.0f);
 }
 
 /* ============================================================
    Moon
    ============================================================ */
 void drawMoon(void)
 {
     float mx = mapX2D(0.78f);
     float my = mapY2D(0.78f) + 8.0f;
     float mz = -54.0f;
     float r  = 0.055f * SCENE_SCALE;

     glColor3f(1.0f, 0.97f, 0.75f);
     fillDisk3D(mx, my, mz, r, 32, 2);
     glColor3f(0.06f, 0.06f, 0.07f);
     fillDisk3D(mx + 0.02f * SCENE_SCALE, my + 0.02f * SCENE_SCALE, mz + 0.05f,
                r * 0.76f, 32, 2);
 }
 
 /* ============================================================
    Ground (pavement / footpath)
    ============================================================ */
 void drawGround(void)
 {
     pushOriginal2D(0.02f);
     glColor3f(0.55f, 0.55f, 0.55f);
     fillRect(SCENE_X_LEFT, -0.50f, SCENE_X_WIDTH, 0.08f);
     glColor3f(0.18f, 0.52f, 0.18f);
     fillRect(SCENE_X_LEFT, -0.50f, SCENE_X_WIDTH, 0.06f);
     fillRect(SCENE_X_LEFT, -0.98f, SCENE_X_WIDTH, 0.06f);
     popOriginal2D();
 }

 /* ============================================================
    Building 3D (same colors/windows/door as original 2D design)
    x,y,w,h = original 2D layout coordinates
    ============================================================ */
 void drawBuilding(float x, float y, float w, float h,
                   int wCols, int wRows, int hasDoor,
                   float cr, float cg, float cb)
 {
     int   r, c;
     float padX, padY, areaW, areaH;
     float winW, winH, gapX, gapY;
     float wx, wy;
     float dw, dh, dx, dy, kx, ky;
     float bx, by, bw, bh, bz, bd, fz;
     float winEmR, winEmG, winEmB;

     bx = mapX2D(x);
     by = mapY2D(y);
     bw = w * SCENE_SCALE;
     bh = h * SCENE_SCALE;
     bz = BUILDING_ROW_Z;
     bd = bw * BUILDING_DEPTH_MUL;
     fz = bz + bd + 0.02f;

     /* --- 3D body: lit faces with normals (depth from lighting) --- */
     lightingSetMaterial(cr, cg, cb, 18.0f);
     fillQuad3D_n(0.0f, 0.0f, 1.0f,
                  bx, by, fz, bx + bw, by, fz, bx + bw, by + bh, fz, bx, by + bh, fz);

     fillQuad3D_n(0.0f, 0.0f, -1.0f,
                  bx + bw, by, bz, bx, by, bz, bx, by + bh, bz, bx + bw, by + bh, bz);
     fillQuad3D_n(1.0f, 0.0f, 0.0f,
                  bx + bw, by, bz, bx + bw, by, fz, bx + bw, by + bh, fz, bx + bw, by + bh, bz);
     fillQuad3D_n(-1.0f, 0.0f, 0.0f,
                  bx, by, fz, bx, by, bz, bx, by + bh, bz, bx, by + bh, fz);

     lightingSetMaterial(cr * 0.92f, cg * 0.92f, cb * 0.92f, 10.0f);
     fillQuad3D_n(0.0f, 1.0f, 0.0f,
                  bx, by + bh, fz, bx + bw, by + bh, fz, bx + bw, by + bh, bz, bx, by + bh, bz);
     fillQuad3D_n(0.0f, -1.0f, 0.0f,
                  bx, by, bz, bx + bw, by, bz, bx + bw, by, fz, bx, by, fz);

     lightingDisableFor2D();
     glColor3f(0.1f, 0.1f, 0.1f);
     glLineWidth(1.2f);
     outlineBox3D(bx, by, bz, bw, bh, bd);
     lightingApplyForScene(gNightMode);

     /* --- windows on front face (warm glow, stronger at night) --- */
     padX  = w * 0.12f;
     padY  = h * 0.10f;
     areaW = w - 2.0f * padX;
     areaH = h - 2.0f * padY;
     winW  = areaW / ((float)wCols * 1.6f);
     winH  = areaH / ((float)wRows * 1.6f);
     gapX  = (areaW - (float)wCols * winW) / ((float)wCols + 1.0f);
     gapY  = (areaH - (float)wRows * winH) / ((float)wRows + 1.0f);

     if (gNightMode) {
         winEmR = 0.55f; winEmG = 0.50f; winEmB = 0.22f;
     } else {
         winEmR = 0.08f; winEmG = 0.07f; winEmB = 0.03f;
     }

     glEnable(GL_POLYGON_OFFSET_FILL);
     glPolygonOffset(-1.0f, -1.0f);

     for (r = 0; r < wRows; r++) {
         for (c = 0; c < wCols; c++) {
             float wx1, wy1, wx2, wy2;

             wx = x + padX + gapX + (float)c * (winW + gapX);
             wy = y + padY + gapY + (float)r * (winH + gapY);
             wx1 = mapX2D(wx);
             wy1 = mapY2D(wy);
             wx2 = mapX2D(wx + winW);
             wy2 = mapY2D(wy + winH);

             lightingSetMaterialEmissive(1.0f, 0.95f, 0.60f, winEmR, winEmG, winEmB);
             fillQuad3D_n(0.0f, 0.0f, 1.0f,
                          wx1, wy1, fz + 0.04f, wx2, wy1, fz + 0.04f,
                          wx2, wy2, fz + 0.04f, wx1, wy2, fz + 0.04f);

             lightingDisableFor2D();
             glColor3f(0.3f, 0.3f, 0.35f);
             glBegin(GL_LINE_LOOP);
                 glVertex3f(wx1, wy1, fz + 0.05f);
                 glVertex3f(wx2, wy1, fz + 0.05f);
                 glVertex3f(wx2, wy2, fz + 0.05f);
                 glVertex3f(wx1, wy2, fz + 0.05f);
             glEnd();

             glBegin(GL_LINES);
                 glVertex3f((wx1 + wx2) * 0.5f, wy1, fz + 0.05f);
                 glVertex3f((wx1 + wx2) * 0.5f, wy2, fz + 0.05f);
                 glVertex3f(wx1, (wy1 + wy2) * 0.5f, fz + 0.05f);
                 glVertex3f(wx2, (wy1 + wy2) * 0.5f, fz + 0.05f);
             glEnd();
             lightingApplyForScene(gNightMode);
         }
     }

     glDisable(GL_POLYGON_OFFSET_FILL);

     /* --- door on front face --- */
     if (hasDoor) {
         float dx1, dy1, dx2, dy2;

         dw = w * 0.20f;
         dh = h * 0.16f;
         dx = x + (w - dw) * 0.5f;
         dy = y;
         dx1 = mapX2D(dx);
         dy1 = mapY2D(dy);
         dx2 = mapX2D(dx + dw);
         dy2 = mapY2D(dy + dh);

         lightingSetMaterial(0.45f, 0.27f, 0.10f, 8.0f);
         fillQuad3D_n(0.0f, 0.0f, 1.0f,
                      dx1, dy1, fz + 0.05f, dx2, dy1, fz + 0.05f,
                      dx2, dy2, fz + 0.05f, dx1, dy2, fz + 0.05f);

         lightingSetMaterial(0.35f, 0.20f, 0.07f, 6.0f);
         fillQuad3D_n(0.0f, 0.0f, 1.0f,
                      mapX2D(dx + dw*0.08f), mapY2D(dy + dh*0.55f), fz + 0.06f,
                      mapX2D(dx + dw*0.92f), mapY2D(dy + dh*0.55f), fz + 0.06f,
                      mapX2D(dx + dw*0.92f), mapY2D(dy + dh*0.93f), fz + 0.06f,
                      mapX2D(dx + dw*0.08f), mapY2D(dy + dh*0.93f), fz + 0.06f);
         fillQuad3D_n(0.0f, 0.0f, 1.0f,
                      mapX2D(dx + dw*0.08f), mapY2D(dy + dh*0.10f), fz + 0.06f,
                      mapX2D(dx + dw*0.92f), mapY2D(dy + dh*0.10f), fz + 0.06f,
                      mapX2D(dx + dw*0.92f), mapY2D(dy + dh*0.48f), fz + 0.06f,
                      mapX2D(dx + dw*0.08f), mapY2D(dy + dh*0.48f), fz + 0.06f);

         lightingDisableFor2D();
         glColor3f(0.20f, 0.10f, 0.02f);
         glBegin(GL_LINE_LOOP);
             glVertex3f(dx1, dy1, fz + 0.07f);
             glVertex3f(dx2, dy1, fz + 0.07f);
             glVertex3f(dx2, dy2, fz + 0.07f);
             glVertex3f(dx1, dy2, fz + 0.07f);
         glEnd();

         kx = mapX2D(dx + dw * 0.78f);
         ky = mapY2D(dy + dh * 0.42f);
         glColor3f(0.90f, 0.75f, 0.10f);
         fillDisk3D(kx, ky, fz + 0.08f, dw * 0.07f, 12, 2);

         glColor3f(0.65f, 0.65f, 0.65f);
         fillQuad3D(mapX2D(dx - dw*0.1f), mapY2D(dy - 0.008f), fz + 0.06f,
                    mapX2D(dx + dw*1.1f), mapY2D(dy - 0.008f), fz + 0.06f,
                    mapX2D(dx + dw*1.1f), mapY2D(dy), fz + 0.06f,
                    mapX2D(dx - dw*0.1f), mapY2D(dy), fz + 0.06f);
         lightingApplyForScene(gNightMode);
     }
 }

 /* Buildings row - edge to edge full width (-1 .. +1) */
 void drawBuildingsRow(void)
 {
     float x = -1.0f;

     drawBuilding(x, -0.42f, 0.238f, 0.75f, 2, 5, 0,  0.22f,0.28f,0.42f); x += 0.238f;
     drawBuilding(x, -0.42f, 0.262f, 0.60f, 2, 4, 1,  0.28f,0.38f,0.55f); x += 0.262f;
     drawBuilding(x, -0.42f, 0.214f, 0.80f, 2, 5, 0,  0.55f,0.65f,0.78f); x += 0.214f;
     drawBuilding(x, -0.42f, 0.167f, 0.90f, 2, 6, 0,  0.82f,0.84f,0.88f); x += 0.167f;
     drawBuilding(x, -0.42f, 0.190f, 0.65f, 2, 4, 0,  0.50f,0.52f,0.56f); x += 0.190f;
     drawBuilding(x, -0.42f, 0.238f, 0.55f, 2, 4, 1,  0.78f,0.74f,0.62f); x += 0.238f;
     drawBuilding(x, -0.42f, 0.262f, 0.70f, 2, 5, 0,  0.30f,0.50f,0.52f); x += 0.262f;
     drawBuilding(x, -0.42f, 0.262f, 0.75f, 2, 5, 0,  0.38f,0.44f,0.58f); x += 0.262f;
     drawBuilding(x, -0.42f, 0.167f, 0.60f, 2, 4, 0,  0.88f,0.86f,0.76f);
     (void)x;
 }

 /* ============================================================
    Traffic Light
    ============================================================ */
 void drawTrafficLight(float x, float baseY)
 {
     float bx, by, bw, bh, cx;
     float pad, slot, r;
     float yRed, yYellow, yGreen;
     int   state;

     state = animationGetLightState();

     pushOriginal2D(0.22f);
     glDisable(GL_DEPTH_TEST);

     glColor3f(0.25f, 0.25f, 0.25f);
     fillRect(x - 0.005f, baseY, 0.010f, 0.30f);

     bx = x - 0.028f;
     by = baseY + 0.155f;
     bw = 0.056f;
     bh = 0.150f;
     glColor3f(0.05f, 0.05f, 0.05f);
     fillRect(bx, by, bw, bh);
     glColor3f(0.35f, 0.35f, 0.35f);
     outlineRect(bx, by, bw, bh);

     cx   = x;
     pad  = bh * 0.13f;
     slot = (bh - 2.0f * pad) / 2.0f;
     r    = slot * 0.34f;

     yGreen  = by + pad;
     yYellow = by + pad + slot;
     yRed    = by + pad + slot * 2.0f;

     drawSignalLamp(cx, yRed,    r, state == ANIM_LIGHT_RED,
                    1.0f, 0.0f, 0.0f);
     drawSignalLamp(cx, yYellow, r, state == ANIM_LIGHT_YELLOW,
                    1.0f, 0.92f, 0.0f);
     drawSignalLamp(cx, yGreen,  r, state == ANIM_LIGHT_GREEN,
                    0.0f, 1.0f, 0.0f);

     glEnable(GL_DEPTH_TEST);
     popOriginal2D();
 }
 
 /* ============================================================
    Tree
    ============================================================ */
 void drawTree(float x, float y)
 {
     pushOriginal2D(0.10f);

     glColor3f(0.45f, 0.28f, 0.10f);
     fillRect(x - 0.008f, y, 0.016f, 0.10f);
     glColor3f(0.25f, 0.14f, 0.04f);
     outlineRect(x - 0.008f, y, 0.016f, 0.10f);

     glColor3f(0.10f, 0.45f, 0.12f);
     fillCircle(x,          y + 0.145f, 0.065f, 24);
     fillCircle(x - 0.02f,  y + 0.130f, 0.040f, 20);
     fillCircle(x + 0.022f, y + 0.155f, 0.035f, 20);

     glColor3f(0.06f, 0.30f, 0.08f);
     outlineCircle(x, y + 0.145f, 0.065f, 24);

     popOriginal2D();
 }
 
 /* ============================================================
    Road
    ============================================================ */
 void drawRoad(void)
 {
     float roadY = -0.72f;
     float roadH =  0.30f;
     float dashW = 0.06f;
     float dashH = 0.009f;
     float gy, gx;

     pushOriginal2D(0.05f);

     glColor3f(0.22f, 0.22f, 0.22f);
     fillRect(SCENE_X_LEFT, roadY, SCENE_X_WIDTH, roadH);

     glColor3f(0.9f, 0.9f, 0.9f);
     fillRect(SCENE_X_LEFT, roadY + roadH - 0.008f, SCENE_X_WIDTH, 0.008f);
     fillRect(SCENE_X_LEFT, roadY,                  SCENE_X_WIDTH, 0.008f);

     glColor3f(0.95f, 0.85f, 0.0f);
     gy = roadY + roadH * 0.25f - dashH * 0.5f;
     for (gx = SCENE_X_LEFT; gx < SCENE_X_LEFT + SCENE_X_WIDTH - dashW; gx += 0.14f)
         fillRect(gx, gy, dashW, dashH);
     gy = roadY + roadH * 0.75f - dashH * 0.5f;
     for (gx = SCENE_X_LEFT; gx < SCENE_X_LEFT + SCENE_X_WIDTH - dashW; gx += 0.14f)
         fillRect(gx, gy, dashW, dashH);

     popOriginal2D();
 }
 
 /* ============================================================
    Crosswalk
    ============================================================ */
 void drawCrosswalk(float x, float roadY, float roadH)
 {
     int   i, n = 6;
     float cw   = 0.13f;
     float strH = 0.022f;
     float gap  = (roadH - (float)n * strH) / ((float)n + 1.0f);
     float sy;

     pushOriginal2D(0.08f);

     for (i = 0; i < n; i++) {
         sy = roadY + gap + (float)i * (strH + gap);
         glColor3f(0.95f, 0.95f, 0.95f);
         fillRect(x, sy, cw, strH);
         glColor3f(0.5f, 0.5f, 0.5f);
         outlineRect(x, sy, cw, strH);
     }

     popOriginal2D();
 }
 
 /* STOP label stamps — mirror each letter shape for correct street-side view */
 static void stampRectStop(float ox, float oy, float ps,
                           float gx, float gy, float gw, float gh)
 {
     float mx = 5.0f - gx - gw;
     fillRect(ox + mx * ps, oy + gy * ps, gw * ps, gh * ps);
 }

 static void drawBlockLetter2D(int ch, float ox, float oy, float ps)
 {
     switch (ch) {
     case 'S':
         stampRectStop(ox, oy, ps, 1,0,3,1);
         stampRectStop(ox, oy, ps, 0,1,1,1);
         stampRectStop(ox, oy, ps, 1,2,3,1);
         stampRectStop(ox, oy, ps, 4,3,1,1);
         stampRectStop(ox, oy, ps, 1,4,3,1);
         break;
     case 'T':
         stampRectStop(ox, oy, ps, 0,0,5,1);
         stampRectStop(ox, oy, ps, 2,1,1,4);
         break;
     case 'O':
         stampRectStop(ox, oy, ps, 1,0,3,1);
         stampRectStop(ox, oy, ps, 0,1,1,3);
         stampRectStop(ox, oy, ps, 4,1,1,3);
         stampRectStop(ox, oy, ps, 1,4,3,1);
         break;
     case 'P':
         stampRectStop(ox, oy, ps, 0,0,1,5);
         stampRectStop(ox, oy, ps, 1,0,3,1);
         stampRectStop(ox, oy, ps, 1,2,3,1);
         stampRectStop(ox, oy, ps, 4,1,1,1);
         break;
     default:
         break;
     }
 }

 static void drawStopLabel2D(float cx, float cy)
 {
     const char *s = "STOP";
     float ps = 0.0038f;
     float letterW = 5.0f * ps;
     float gap     = ps * 0.45f;
     float totalW  = letterW * 4.0f + gap * 3.0f;
     float x       = cx - totalW * 0.5f;
     float y       = cy - 2.5f * ps;
     int   i;

     glColor3f(1.0f, 1.0f, 1.0f);
     for (i = 0; s[i]; i++) {
         drawBlockLetter2D((int)s[i], x, y, ps);
         x += letterW + gap;
     }
 }

 /* ============================================================
    STOP SIGN — flat face on road plane (pole + board + STOP text)
    ============================================================ */
 void drawStopSign(float x, float y)
 {
     float r, inner, signCY, ang;
     int   i;

     r      = 0.038f;
     inner  = r * 0.78f;
     signCY = y + 0.10f;

     lightingDisableFor2D();

     pushOriginal2D(0.25f);

     glColor3f(0.55f, 0.55f, 0.58f);
     fillRect(x - 0.004f, y, 0.008f, 0.058f);

     glColor3f(0.88f, 0.06f, 0.06f);
     glBegin(GL_POLYGON);
     for (i = 0; i < 8; i++) {
         ang = (float)(M_PI / 8.0 + i * M_PI / 4.0);
         glVertex2f(x + r * (float)cos(ang), signCY + r * (float)sin(ang));
     }
     glEnd();

     glColor3f(1.0f, 1.0f, 1.0f);
     glLineWidth(2.5f);
     glBegin(GL_LINE_LOOP);
     for (i = 0; i < 8; i++) {
         ang = (float)(M_PI / 8.0 + i * M_PI / 4.0);
         glVertex2f(x + inner * (float)cos(ang), signCY + inner * (float)sin(ang));
     }
     glEnd();
     glLineWidth(1.2f);

     drawStopLabel2D(x, signCY);

     popOriginal2D();
 }
 
 /* ============================================================
    CAR - ORIGINAL design preserved on 3D road plane
    cx,cy = bottom-left of car body (original 2D coords)
    ============================================================ */
 void drawCar(float cx, float cy, float w, float bodyR, float bodyG, float bodyB,
              float doorOpen)
 {
     float h, cabX, cabW, cabH, wr;
     float doorX, doorY, doorW, doorH;
     float kx, ky;
     float dShift, dLift;

     pushOriginal2D(0.15f);

     h    = w * 0.38f;
     cabX = cx + w * 0.20f;
     cabW = w  * 0.52f;
     cabH = h  * 0.60f;
     wr   = w  * 0.115f;

     glColor3f(0.10f, 0.10f, 0.10f);
     fillCircle(cx + w*0.3f, cy - 0.005f, w*0.10f, 20);
     fillCircle(cx + w*0.75f, cy - 0.005f, w*0.10f, 20);

     glColor3f(bodyR, bodyG, bodyB);
     fillRect(cx, cy, w, h);
     glColor3f(bodyR*0.4f, bodyG*0.4f, bodyB*0.4f);
     outlineRect(cx, cy, w, h);

     glColor3f(bodyR*0.85f, bodyG*0.85f, bodyB*0.85f);
     fillRect(cabX, cy + h, cabW, cabH);
     glColor3f(bodyR*0.4f, bodyG*0.4f, bodyB*0.4f);
     outlineRect(cabX, cy + h, cabW, cabH);

     glColor3f(0.55f, 0.80f, 0.95f);
     fillRect(cabX + cabW*0.52f, cy + h + cabH*0.12f, cabW*0.42f, cabH*0.76f);
     glColor3f(0.3f, 0.5f, 0.7f);
     outlineRect(cabX + cabW*0.52f, cy + h + cabH*0.12f, cabW*0.42f, cabH*0.76f);
     glColor3f(0.55f, 0.80f, 0.95f);
     fillRect(cabX + cabW*0.06f, cy + h + cabH*0.12f, cabW*0.42f, cabH*0.76f);
     glColor3f(0.3f, 0.5f, 0.7f);
     outlineRect(cabX + cabW*0.06f, cy + h + cabH*0.12f, cabW*0.42f, cabH*0.76f);

     doorW = w  * 0.38f;
     doorH = h  * 0.80f;
     doorX = cx + w * 0.30f;
     doorY = cy + h * 0.10f;
     dShift = doorOpen * doorW * 0.55f;
     dLift  = doorOpen * doorH * 0.12f;
     doorX += dShift;
     doorY += dLift;

     glColor3f(bodyR*0.80f, bodyG*0.80f, bodyB*0.80f);
     fillRect(doorX, doorY, doorW, doorH);
     glColor3f(bodyR*0.35f, bodyG*0.35f, bodyB*0.35f);
     glLineWidth(2.0f);
     outlineRect(doorX, doorY, doorW, doorH);
     glLineWidth(1.2f);

     glColor3f(0.55f, 0.80f, 0.95f);
     fillRect(doorX + doorW*0.08f, doorY + doorH*0.52f,
              doorW*0.84f,         doorH*0.40f);
     glColor3f(0.3f, 0.5f, 0.7f);
     outlineRect(doorX + doorW*0.08f, doorY + doorH*0.52f,
                 doorW*0.84f,         doorH*0.40f);

     kx = doorX + doorW * 0.78f;
     ky = doorY + doorH * 0.35f;
     glColor3f(0.80f, 0.80f, 0.80f);
     fillRect(kx, ky, doorW*0.12f, doorH*0.06f);
     glColor3f(0.4f, 0.4f, 0.4f);
     outlineRect(kx, ky, doorW*0.12f, doorH*0.06f);

     glColor3f(bodyR*0.35f, bodyG*0.35f, bodyB*0.35f);
     glBegin(GL_LINES);
         glVertex2f(doorX, doorY);
         glVertex2f(doorX, doorY + doorH);
         glVertex2f(doorX + doorW, doorY);
         glVertex2f(doorX + doorW, doorY + doorH);
     glEnd();

     glColor3f(0.10f, 0.10f, 0.10f);
     fillCircle(cx + w*0.22f, cy, wr,       24);
     fillCircle(cx + w*0.78f, cy, wr,       24);
     glColor3f(0.75f, 0.75f, 0.75f);
     fillCircle(cx + w*0.22f, cy, wr*0.50f, 20);
     fillCircle(cx + w*0.78f, cy, wr*0.50f, 20);
     glColor3f(0.40f, 0.40f, 0.40f);
     fillCircle(cx + w*0.22f, cy, wr*0.15f, 10);
     fillCircle(cx + w*0.78f, cy, wr*0.15f, 10);
     glColor3f(0.0f, 0.0f, 0.0f);
     outlineCircle(cx + w*0.22f, cy, wr, 24);
     outlineCircle(cx + w*0.78f, cy, wr, 24);

     glColor3f(1.0f, 1.0f, 0.70f);
     if (doorOpen > 0.5f) glColor3f(1.0f, 0.85f, 0.0f);
     fillRect(cx + w*0.92f, cy + h*0.28f, w*0.08f, h*0.22f);
     glColor3f(0.7f, 0.7f, 0.3f);
     outlineRect(cx + w*0.92f, cy + h*0.28f, w*0.08f, h*0.22f);

     glColor3f(0.9f, 0.1f, 0.1f);
     fillRect(cx, cy + h*0.30f, w*0.06f, h*0.20f);
     glColor3f(0.5f, 0.0f, 0.0f);
     outlineRect(cx, cy + h*0.30f, w*0.06f, h*0.20f);

     glColor3f(0.70f, 0.70f, 0.70f);
     fillRect(cx + w*0.88f, cy, w*0.12f, h*0.14f);
     outlineRect(cx + w*0.88f, cy, w*0.12f, h*0.14f);

     popOriginal2D();
 }
 
 /* ============================================================
    HUD text helper
    ============================================================ */
 void drawText(float x, float y, const char *txt, void *font)
 {
     glRasterPos2f(x, y);
     while (*txt)
         glutBitmapCharacter(font, (int)*txt++);
 }
 
 /* ============================================================
    Scene draw - full 3D traffic view + HUD
    ============================================================ */
 void sceneDraw(void)
 {
     float roadY = -0.72f;
     float roadH =  0.30f;

     applySceneBackground();
     glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
     cameraApply();

     /* === BACKGROUND (same light/dark as clear color) === */
     drawSky();
 
     if (gNightMode) {
         drawStars();
         drawMoon();
     }
 
     /* === GROUND / FOOTPATH === */
     drawGround();

     /* === BUILDINGS - lit 3D with depth === */
     lightingApplyForScene(gNightMode);
     drawBuildingsRow();
     lightingDisableFor2D();

     /* === TREES === */
     drawTree(-0.62f, -0.44f);
     drawTree(-0.03f, -0.44f);
     drawTree( 0.30f, -0.44f);
     drawTree( 0.88f, -0.44f);

     /* === TRAFFIC LIGHTS === */
     drawTrafficLight(-0.35f, -0.44f);
     drawTrafficLight( 0.05f, -0.44f);
 
     /* === STOP SIGN (beside right traffic light) === */
     drawStopSign(0.18f, -0.44f);
 
     /* === ROAD === */
     drawRoad();
 
     /* === CROSSWALKS === */
     drawCrosswalk(-0.55f, roadY, roadH);
     drawCrosswalk( 0.43f, roadY, roadH);
 
     /* === CARS (positions from animation module) === */
     {
         int i, n;
         float cx, cy, cw, cr, cg, cb, door;

         n = animationGetCarCount();
         for (i = 0; i < n; i++) {
             if (!animationIsCarActive(i))
                 continue;
             animationGetCar(i, &cx, &cy, &cw, &cr, &cg, &cb);
             door = animationGetCarDoorOpen(i);
             drawCar(cx, cy, cw, cr, cg, cb, door);
         }
     }
 
     /* === HUD (2D overlay - unchanged colors/text) === */
     glDisable(GL_DEPTH_TEST);
     cameraApplyHUD();

     glColor3f(0.0f, 0.0f, 0.0f);
     fillRect(-1.0f, 0.87f, 2.0f, 0.13f);
 
     if (animationGetLightState() == ANIM_LIGHT_RED) {
         glColor3f(1.0f, 0.3f, 0.3f);
         drawText(-0.98f, 0.91f, "SIGNAL: RED  - Car STOPPED", GLUT_BITMAP_9_BY_15);
     } else if (animationGetLightState() == ANIM_LIGHT_GREEN) {
         glColor3f(0.3f, 1.0f, 0.3f);
         drawText(-0.98f, 0.91f, "SIGNAL: GREEN - Cars moving FAST", GLUT_BITMAP_9_BY_15);
     } else {
         glColor3f(1.0f, 1.0f, 0.2f);
         drawText(-0.98f, 0.91f, "SIGNAL: YELLOW - Cars moving SLOW", GLUT_BITMAP_9_BY_15);
     }
 
     glColor3f(0.75f, 0.75f, 0.75f);
     if (animationIsHornActive())
         drawText(-0.98f, 0.875f, "HORN at STOP sign!", GLUT_BITMAP_8_BY_13);
     if (!soundIsEnabled())
         drawText(0.55f, 0.875f, "SOUND MUTED (M)", GLUT_BITMAP_8_BY_13);
     if (animationIsPaused())
         drawText(0.55f, 0.84f, "PAUSED (P)", GLUT_BITMAP_8_BY_13);
     {
         const char *msg = exportGetStatusMessage();
         if (msg[0])
             drawText(-0.98f, 0.805f, msg, GLUT_BITMAP_8_BY_13);
     }
     drawText(0.05f, 0.91f, "H=Help P=Pause S=Shot F=Full  Arrows=Cam  R/G/Y  N  M  ESC",
              GLUT_BITMAP_8_BY_13);

     if (gHelpVisible) {
         glColor3f(0.0f, 0.0f, 0.0f);
         fillRect(-0.95f, -0.55f, 1.90f, 0.42f);
         glColor3f(0.9f, 0.9f, 0.5f);
         drawText(-0.92f, -0.18f, "HELP - Traffic Signal Scene", GLUT_BITMAP_9_BY_15);
         glColor3f(0.85f, 0.85f, 0.85f);
         drawText(-0.92f, -0.26f, "R=Red(stop)  G=Green(fast)  Y=Yellow(slow)", GLUT_BITMAP_8_BY_13);
         drawText(-0.92f, -0.32f, "Arrows=Rotate camera   +/- = Zoom   0 = Reset view", GLUT_BITMAP_8_BY_13);
         drawText(-0.92f, -0.38f, "N=Night/Day  M=Mute  P=Pause  S=Screenshot  F=Fullscreen", GLUT_BITMAP_8_BY_13);
         drawText(-0.92f, -0.44f, "H=Hide help  ESC=Quit  |  CLI: --night --day --size W H --mute", GLUT_BITMAP_8_BY_13);
     }

     exportCaptureIfRequested();
     exportTickMessage();

     glEnable(GL_DEPTH_TEST);
     glutSwapBuffers();
 }

 void sceneInit(void)
 {
     gNightMode    = 1;
     gHelpVisible  = 0;
     lightingInit();
     applySceneBackground();
 }

 void sceneToggleNight(void)
 {
     gNightMode = !gNightMode;
     applySceneBackground();
 }

 void sceneSetNightMode(int nightOn)
 {
     gNightMode = nightOn ? 1 : 0;
     applySceneBackground();
 }

 int sceneIsNightMode(void)
 {
     return gNightMode;
 }

 void sceneToggleHelp(void)
 {
     gHelpVisible = !gHelpVisible;
 }

 int sceneIsHelpVisible(void)
 {
     return gHelpVisible;
 }
