/*
 * lighting.cpp - directional sun/moon + ambient for 3D depth
 */

#ifdef __APPLE__
#define GL_SILENCE_DEPRECATION
#include <OpenGL/gl.h>
#else
#include <GL/gl.h>
#endif

#include "lighting.h"

void lightingInit(void)
{
    glEnable(GL_DEPTH_TEST);
    glDepthFunc(GL_LEQUAL);
    glEnable(GL_NORMALIZE);
    glShadeModel(GL_SMOOTH);

    glLightModeli(GL_LIGHT_MODEL_LOCAL_VIEWER, GL_TRUE);
    glLightModeli(GL_LIGHT_MODEL_TWO_SIDE, GL_FALSE);
}

void lightingApplyForScene(int nightMode)
{
    float ambGlobal[]  = {0.0f, 0.0f, 0.0f, 1.0f};
    float ambScene[]   = {0.0f, 0.0f, 0.0f, 1.0f};
    float dir0Pos[]    = {0.35f, 1.0f, 0.55f, 0.0f};
    float dir0Diff[]   = {0.0f, 0.0f, 0.0f, 1.0f};
    float dir0Spec[]   = {0.12f, 0.12f, 0.14f, 1.0f};
    float fillPos[]    = {-0.6f, 0.4f, 0.8f, 0.0f};
    float fillDiff[]   = {0.0f, 0.0f, 0.0f, 1.0f};

    if (nightMode) {
        ambGlobal[0] = 0.10f; ambGlobal[1] = 0.10f; ambGlobal[2] = 0.10f;
        ambScene[0]  = 0.08f; ambScene[1]  = 0.08f; ambScene[2]  = 0.08f;
        dir0Diff[0]  = 0.45f; dir0Diff[1]  = 0.45f; dir0Diff[2]  = 0.46f;
        fillDiff[0]  = 0.14f; fillDiff[1]  = 0.14f; fillDiff[2]  = 0.14f;
    } else {
        ambGlobal[0] = 0.38f; ambGlobal[1] = 0.38f; ambGlobal[2] = 0.40f;
        ambScene[0]  = 0.28f; ambScene[1]  = 0.28f; ambScene[2]  = 0.30f;
        dir0Diff[0]  = 1.00f; dir0Diff[1]  = 0.96f; dir0Diff[2]  = 0.88f;
        fillDiff[0]  = 0.35f; fillDiff[1]  = 0.38f; fillDiff[2]  = 0.42f;
    }

    glEnable(GL_LIGHTING);
    glEnable(GL_LIGHT0);
    glEnable(GL_LIGHT1);

    glLightModelfv(GL_LIGHT_MODEL_AMBIENT, ambGlobal);

    glLightfv(GL_LIGHT0, GL_POSITION, dir0Pos);
    glLightfv(GL_LIGHT0, GL_AMBIENT, ambScene);
    glLightfv(GL_LIGHT0, GL_DIFFUSE, dir0Diff);
    glLightfv(GL_LIGHT0, GL_SPECULAR, dir0Spec);

    glLightfv(GL_LIGHT1, GL_POSITION, fillPos);
    glLightfv(GL_LIGHT1, GL_AMBIENT, ambGlobal);
    glLightfv(GL_LIGHT1, GL_DIFFUSE, fillDiff);
    glLightfv(GL_LIGHT1, GL_SPECULAR, dir0Spec);

    glColorMaterial(GL_FRONT, GL_AMBIENT_AND_DIFFUSE);
    glEnable(GL_COLOR_MATERIAL);
}

void lightingDisableFor2D(void)
{
    glDisable(GL_LIGHTING);
    glDisable(GL_LIGHT0);
    glDisable(GL_LIGHT1);
    glDisable(GL_COLOR_MATERIAL);
}

void lightingSetMaterial(float r, float g, float b, float shininess)
{
    float amb[]  = {r * 0.35f, g * 0.35f, b * 0.35f, 1.0f};
    float diff[] = {r, g, b, 1.0f};
    float spec[] = {0.18f, 0.18f, 0.20f, 1.0f};
    float emi[]  = {0.0f, 0.0f, 0.0f, 1.0f};

    glMaterialfv(GL_FRONT, GL_AMBIENT, amb);
    glMaterialfv(GL_FRONT, GL_DIFFUSE, diff);
    glMaterialfv(GL_FRONT, GL_SPECULAR, spec);
    glMaterialfv(GL_FRONT, GL_EMISSION, emi);
    glMaterialf(GL_FRONT, GL_SHININESS, shininess);
}

void lightingSetMaterialEmissive(float r, float g, float b,
                                 float er, float eg, float eb)
{
    float amb[]  = {r * 0.55f, g * 0.55f, b * 0.55f, 1.0f};
    float diff[] = {r, g, b, 1.0f};
    float spec[] = {0.25f, 0.25f, 0.20f, 1.0f};
    float emi[]  = {er, eg, eb, 1.0f};

    glMaterialfv(GL_FRONT, GL_AMBIENT, amb);
    glMaterialfv(GL_FRONT, GL_DIFFUSE, diff);
    glMaterialfv(GL_FRONT, GL_SPECULAR, spec);
    glMaterialfv(GL_FRONT, GL_EMISSION, emi);
    glMaterialf(GL_FRONT, GL_SHININESS, 12.0f);
}
