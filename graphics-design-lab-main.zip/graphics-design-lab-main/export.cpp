/*
 * export.cpp - save framebuffer as PPM, toggle fullscreen
 *
 * S key  -> traffic_scene_0001.ppm (in project folder)
 * F key  -> fullscreen on / off
 */

#ifdef __APPLE__
#define GL_SILENCE_DEPRECATION
#include <OpenGL/gl.h>
#include <GLUT/glut.h>
#else
#include <GL/gl.h>
#include <GL/glut.h>
#endif

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "export.h"

static int   gWinW        = 1000;
static int   gWinH        = 650;
static int   gWinX        = 60;
static int   gWinY        = 40;
static int   gFullscreen  = 0;
static int   gShotPending = 0;
static int   gShotCounter = 0;
static int   gMsgFrames   = 0;
static char  gMsg[96]     = "";

void exportInit(int width, int height)
{
    gWinW = width > 0 ? width : 1000;
    gWinH = height > 0 ? height : 650;
}

void exportRequestScreenshot(void)
{
    gShotPending = 1;
}

static int writePpm(const char *path, int w, int h, const unsigned char *rgb)
{
    FILE *fp;
    int x, y, row;

    fp = fopen(path, "wb");
    if (!fp)
        return 0;

    fprintf(fp, "P6\n%d %d\n255\n", w, h);
    for (y = h - 1; y >= 0; y--) {
        row = y * w * 3;
        for (x = 0; x < w * 3; x++)
            fputc(rgb[row + x], fp);
    }
    fclose(fp);
    return 1;
}

void exportCaptureIfRequested(void)
{
    int w, h, size;
    unsigned char *pixels;
    char path[64];

    if (!gShotPending)
        return;
    gShotPending = 0;

    w = glutGet(GLUT_WINDOW_WIDTH);
    h = glutGet(GLUT_WINDOW_HEIGHT);
    if (w <= 0 || h <= 0)
        return;

    size = w * h * 3;
    pixels = (unsigned char *)malloc((size_t)size);
    if (!pixels)
        return;

    glReadPixels(0, 0, w, h, GL_RGB, GL_UNSIGNED_BYTE, pixels);

    gShotCounter++;
    snprintf(path, sizeof(path), "traffic_scene_%04d.ppm", gShotCounter);

    if (writePpm(path, w, h, pixels)) {
        snprintf(gMsg, sizeof(gMsg), "Saved %s (open in Preview)", path);
        gMsgFrames = 120;
    } else {
        snprintf(gMsg, sizeof(gMsg), "Screenshot failed");
        gMsgFrames = 90;
    }

    free(pixels);
}

void exportToggleFullscreen(void)
{
    if (gFullscreen) {
        glutReshapeWindow(gWinW, gWinH);
        glutPositionWindow(gWinX, gWinY);
        gFullscreen = 0;
        snprintf(gMsg, sizeof(gMsg), "Windowed mode");
    } else {
        gWinW = glutGet(GLUT_WINDOW_WIDTH);
        gWinH = glutGet(GLUT_WINDOW_HEIGHT);
        gWinX = glutGet(GLUT_WINDOW_X);
        gWinY = glutGet(GLUT_WINDOW_Y);
        glutFullScreen();
        gFullscreen = 1;
        snprintf(gMsg, sizeof(gMsg), "Fullscreen (F to exit)");
    }
    gMsgFrames = 90;
}

int exportIsFullscreen(void)
{
    return gFullscreen;
}

const char *exportGetStatusMessage(void)
{
    return gMsgFrames > 0 ? gMsg : "";
}

void exportTickMessage(void)
{
    if (gMsgFrames > 0)
        gMsgFrames--;
}
