/*
 * lighting.h - OpenGL lighting for 3D buildings (day / night)
 */

#ifndef LIGHTING_H
#define LIGHTING_H

#ifdef __cplusplus
extern "C" {
#endif

void lightingInit(void);
void lightingApplyForScene(int nightMode);
void lightingDisableFor2D(void);

void lightingSetMaterial(float r, float g, float b, float shininess);
void lightingSetMaterialEmissive(float r, float g, float b,
                               float er, float eg, float eb);

#ifdef __cplusplus
}
#endif

#endif /* LIGHTING_H */
