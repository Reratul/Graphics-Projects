/*
 * config.h - command-line argument parser (startup options)
 */

#ifndef CONFIG_H
#define CONFIG_H

#ifdef __cplusplus
extern "C" {
#endif

void configParseArgs(int *argc, char **argv);
void configPrintUsage(const char *prog);

int configGetWidth(void);
int configGetHeight(void);
int configGetStartNight(void);  /* -1 = default, 0 = day, 1 = night */
int configGetStartSoundOff(void);

#ifdef __cplusplus
}
#endif

#endif /* CONFIG_H */
