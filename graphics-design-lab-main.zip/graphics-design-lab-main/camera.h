/*
 * camera.h - 3D camera (gluPerspective + gluLookAt)
 * Code::Blocks: add camera.cpp to project, link freeglut opengl32 glu32
 */

#ifndef CAMERA_H
#define CAMERA_H

#ifdef __cplusplus
extern "C" {
#endif

/* Call once from main() before glutMainLoop */
void cameraInit(void);

/* Apply perspective + gluLookAt before drawing 3D scene */
void cameraApply(void);

/* Switch to 2D ortho overlay for HUD text */
void cameraApplyHUD(void);

/* GLUT reshape callback */
void cameraReshape(int w, int h);

/* GLUT special keys: arrow keys orbit camera */
void cameraSpecialKeys(int key, int x, int y);

/* Zoom closer / farther and reset to default view */
void cameraZoomIn(void);
void cameraZoomOut(void);
void cameraReset(void);

#ifdef __cplusplus
}
#endif

#endif /* CAMERA_H */
