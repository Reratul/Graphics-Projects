#include <GL/glut.h>
#include <math.h>

float rotY = 0.0f;

void drawCylinder(float baseRadius, float topRadius, float height) {
    GLUquadric* obj = gluNewQuadric();
    glPushMatrix();
     glRotatef(-90.0f, 1.0f, 0.0f, 0.0f);
    gluCylinder(obj, baseRadius, topRadius, height, 15, 15);
    glPopMatrix();
    gluDeleteQuadric(obj);
}

void drawTree(float length, float radius, int depth) {
    if (depth == 0) {
        glColor3f(0.15f, 0.65f, 0.15f);
        glutSolidSphere(radius * 4.0f, 10, 10);
        return;
    }

    glColor3f(0.5f, 0.35f, 0.1f);

    drawCylinder(radius, radius * 0.7f, length);

    glTranslatef(0.0f, length, 0.0f);

    glPushMatrix();
    glRotatef(30.0f, 0.0f, 0.0f, 1.0f);
    glRotatef(20.0f, 0.0f, 1.0f, 0.0f);
    drawTree(length * 0.75f, radius * 0.7f, depth - 1);
    glPopMatrix();

    glPushMatrix();
    glRotatef(-30.0f, 0.0f, 0.0f, 1.0f);
    glRotatef(-20.0f, 0.0f, 1.0f, 0.0f);
    drawTree(length * 0.75f, radius * 0.7f, depth - 1);
    glPopMatrix();

    glPushMatrix();
    glRotatef(30.0f, 1.0f, 0.0f, 0.0f);
    drawTree(length * 0.75f, radius * 0.7f, depth - 1);
    glPopMatrix();

    glPushMatrix();
    glRotatef(-30.0f, 1.0f, 0.0f, 0.0f);
    drawTree(length * 0.75f, radius * 0.7f, depth - 1);
    glPopMatrix();
}

// ডিসপ্লে ফাংশন
void display() {
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    glLoadIdentity();

    glTranslatef(0.0f, -2.5f, -8.0f);

    glRotatef(rotY, 0.0f, 1.0f, 0.0f);

    drawTree(1.5f, 0.15f, 5);

    glutSwapBuffers();
}


void update(int value) {
    rotY += 0.5f;
    if(rotY > 360.0f) rotY -= 360.0f;

    glutPostRedisplay();
    glutTimerFunc(16, update, 0);
}

void init() {
    glClearColor(0.85f, 0.95f, 1.0f, 1.0f);
    glEnable(GL_DEPTH_TEST);
    glEnable(GL_LIGHTING);
    glEnable(GL_LIGHT0);
    glEnable(GL_COLOR_MATERIAL);


    GLfloat lightPos[] = { 1.0f, 1.0f, 1.0f, 0.0f };
    glLightfv(GL_LIGHT0, GL_POSITION, lightPos);

    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluPerspective(45.0f, 800.0f / 600.0f, 0.1f, 100.0f);
    glMatrixMode(GL_MODELVIEW);
}

int main(int argc, char** argv) {
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);
    glutInitWindowSize(800, 600);
    glutCreateWindow("Complete 3D Fractal Tree - OpenGL");

    init();

    glutDisplayFunc(display);
    glutTimerFunc(16, update, 0);

    glutMainLoop();
    return 0;
}
