#include <GL/glut.h>
#include <math.h>
#include <unistd.h>
#include <thread>
#include <alsa/asoundlib.h>

float sunY = -3.0f;
float sunX = -4.0f;
float birdX = -6.0f;
float birdWingY = 0.0f;
float birdFloat = 0.0f;
bool birdChirped = false;
float treeSway = 0.0f;
float fanAngle = 0.0f;
bool wingUp = true;
bool swayRight = true;

float carX = -8.0f;
float carDoorShift = 0.0f;
int carState = 0;          // 0:Drive, 1:Open, 2:Wait, 3:Close, 4:Away
int carWaitCounter = 0;

bool alertLightOn = true;
int alertFrameTimer = 0;

float camX = 0.0f; float camY = 0.5f; float camZ = 4.2f;

float rotX = 0.0f; float rotY = 0.0f; float rotZ = 0.0f;
float scaleFactor = 1.0f;

float skyR = 0.05f, skyG = 0.05f, skyB = 0.15f;
float windowOpenFactor = 0.0f;
bool isWindowOpen = false;

void playLinuxBeep(unsigned int frequency, unsigned int durationMs) {
    long loops = (durationMs * 1000) / (1000000 / frequency);
    snd_pcm_t *handle;

    if (snd_pcm_open(&handle, "default", SND_PCM_STREAM_PLAYBACK, 0) < 0) return;

    snd_pcm_set_params(handle, SND_PCM_FORMAT_U8, SND_PCM_ACCESS_RW_INTERLEAVED, 1, 11025, 1, 500000);

    unsigned char buffer[1200];
    for (int i = 0; i < 1200; i++) {
        buffer[i] = (sin(2 * M_PI * i * frequency / 11025) > 0) ? 60 : 0;
    }

    for (long i = 0; i < loops / 10; i++) {
        snd_pcm_writei(handle, buffer, 1200);
    }

    snd_pcm_close(handle);
}


void playBirdSoundAsync()
{
    std::thread([](){

        system("aplay -q bird.wav");

    }).detach();
}
void playHornAsync()
{
    std::thread([](){

        playLinuxBeep(450,150);
        usleep(80000);
        playLinuxBeep(450,150);

    }).detach();
}

void draw3DSphere(float x, float y, float z, float r) {
    glPushMatrix();
    glTranslatef(x, y, z);
    glutSolidSphere(r, 24, 24);
    glPopMatrix();
}

void draw3DBox(float x, float y, float z, float width, float height, float depth) {
    glPushMatrix();
    glTranslatef(x, y, z);
    glScalef(width, height, depth);
    glBegin(GL_QUADS);
        glNormal3f(0.0f, 0.0f, 1.0f);
    glEnd();
    glutSolidCube(1.0f);
    glPopMatrix();
}
void draw3DCarStructure() {
    glPushMatrix();
    glTranslatef(carX, -2.1f, -8.0f);
    glColor3f(0.75f, 0.05f, 0.05f);
    draw3DBox(0.0f, -0.15f, 0.0f, 1.6f, 0.25f, 0.8f);
    draw3DBox(-0.5f, 0.15f, 0.0f, 0.6f, 0.35f, 0.8f);
    draw3DBox(0.5f, 0.05f, 0.0f, 0.6f, 0.2f, 0.8f);
    draw3DBox(0.0f, 0.35f, 0.0f, 0.5f, 0.05f, 0.8f);
    draw3DBox(0.25f, 0.2f, 0.35f, 0.08f, 0.35f, 0.08f);
    draw3DBox(0.25f, 0.2f, -0.35f, 0.08f, 0.35f, 0.08f);
    draw3DBox(-0.25f, 0.2f, 0.35f, 0.06f, 0.35f, 0.08f);
    draw3DBox(-0.25f, 0.2f, -0.35f, 0.06f, 0.35f, 0.08f);

    glColor3f(0.5f, 0.7f, 0.9f);
    draw3DBox(0.22f, 0.2f, 0.0f, 0.02f, 0.3f, 0.68f);
    draw3DBox(0.0f, 0.18f, -0.38f, 0.45f, 0.28f, 0.02f);

    glColor3f(0.08f, 0.08f, 0.08f);
    draw3DSphere(-0.45f, -0.22f, 0.42f, 0.18f);
    draw3DSphere(0.45f, -0.22f, 0.42f, 0.18f);
    draw3DSphere(-0.45f, -0.22f, -0.42f, 0.18f);
    draw3DSphere(0.45f, -0.22f, -0.42f, 0.18f);

    glColor3f(0.6f, 0.6f, 0.6f);
    draw3DSphere(-0.45f, -0.22f, 0.45f, 0.08f);
    draw3DSphere(0.45f, -0.22f, 0.45f, 0.08f);
    glPushMatrix();

    glTranslatef(0.22f, 0.05f, 0.39f);
    glRotatef(carDoorShift * 220.0f, 0.0f, 1.0f, 0.0f);
    glTranslatef(-0.22f, 0.0f, 0.0f);
    glColor3f(0.75f, 0.05f, 0.05f);

    draw3DBox(0.0f, 0.0f, 0.0f, 0.44f, 0.22f, 0.03f);
    glColor3f(0.5f, 0.7f, 0.9f);
    draw3DBox(0.0f, 0.18f, 0.0f, 0.42f, 0.14f, 0.01f);

    glDisable(GL_LIGHTING);
    glColor3f(0.2f, 0.0f, 0.0f);
    glLineWidth(2.5f);
    glBegin(GL_LINE_LOOP);
        glVertex3f(-0.22f, 0.25f, 0.02f);
        glVertex3f(0.22f, 0.25f, 0.02f);
        glVertex3f(0.22f, -0.11f, 0.02f);
        glVertex3f(-0.22f, -0.11f, 0.02f);
    glEnd();
    glEnable(GL_LIGHTING);

    glPopMatrix();
    glPopMatrix();
}

void drawOutdoorEnvironment() {
    glDisable(GL_LIGHTING);
    glBegin(GL_QUADS);
    glColor3f(skyR, skyG, skyB);
    glVertex3f(-15.0f, -5.0f, -12.0f); glVertex3f(15.0f, -5.0f, -12.0f);
    glColor3f(skyR * 0.6f, skyG * 0.6f, skyB * 0.8f);
    glVertex3f(15.0f, 10.0f, -12.0f);  glVertex3f(-15.0f, 10.0f, -12.0f);
    glEnd();
    glEnable(GL_LIGHTING);

    glColor3f(1.0f, 0.85f, 0.1f); draw3DSphere(sunX, sunY, -11.5f, 0.65f);

    glColor3f(0.12f, 0.32f, 0.12f);
    glBegin(GL_TRIANGLES);
    glNormal3f(0.0f, 0.0f, 1.0f);
    glVertex3f(-12.0f, -1.5f, -11.0f); glVertex3f(-4.0f, 3.5f, -11.0f); glVertex3f(3.0f, -1.5f, -11.0f);
    glColor3f(0.15f, 0.38f, 0.15f);
    glVertex3f(-3.0f, -1.5f, -10.8f);  glVertex3f(4.0f, 4.2f, -10.8f);  glVertex3f(11.0f, -1.5f, -10.8f);
    glEnd();

    glDisable(GL_LIGHTING);
    if (alertLightOn) {
        glColor3f(1.0f, 0.0f, 0.0f); draw3DSphere(4.0f, 4.35f, -10.7f, 0.12f);
    }
    glEnable(GL_LIGHTING);

    glColor3f(0.18f, 0.18f, 0.18f); draw3DBox(0.0f, -2.5f, -8.0f, 25.0f, 0.08f, 3.5f); // Road
    glColor3f(0.8f, 0.8f, 0.8f);
    for(float i = -10.0f; i <= 10.0f; i += 4.0f) { draw3DBox(i, -2.45f, -8.0f, 1.2f, 0.01f, 0.15f); }

    glColor3f(0.35f, 0.16f, 0.02f); draw3DBox(0.8f, -1.0f, -7.5f, 0.22f, 2.0f, 0.22f); // Tree
    glPushMatrix();
    glTranslatef(0.8f + treeSway, 0.4f, -7.5f);
    glColor3f(0.0f, 0.48f, 0.08f); draw3DSphere(0.0f, 0.0f, 0.0f, 0.7f);
    glColor3f(0.0f, 0.58f, 0.12f); draw3DSphere(0.0f, 0.6f, 0.0f, 0.55f);
    glColor3f(0.0f, 0.68f, 0.15f); draw3DSphere(0.0f, 1.1f, 0.0f, 0.4f);
    glPopMatrix();

    // FlyBird
    float birdY = 3.2f + sin(birdFloat) * 0.15f;
    glDisable(GL_LIGHTING); glColor3f(0.0f, 0.0f, 0.0f); glLineWidth(3.0f);
    glBegin(GL_LINES);
    glVertex3f(birdX, birdY, -9.0f); glVertex3f(birdX - 0.3f, birdY + 0.2f + birdWingY, -9.0f);
    glVertex3f(birdX, birdY, -9.0f); glVertex3f(birdX + 0.3f, birdY + 0.2f + birdWingY, -9.0f);
    glEnd(); glEnable(GL_LIGHTING);

    draw3DCarStructure();
}

void draw3DRoom() {
    glColor3f(0.74f, 0.70f, 0.60f);
    draw3DBox(0.0f, 3.5f, -5.0f, 10.0f, 3.0f, 0.2f);  draw3DBox(0.0f, -3.5f, -5.0f, 10.0f, 3.0f, 0.2f);
    draw3DBox(-3.5f, 0.0f, -5.0f, 3.0f, 4.0f, 0.2f); draw3DBox(3.5f, 0.0f, -5.0f, 3.0f, 4.0f, 0.2f);
    glColor3f(0.38f, 0.24f, 0.14f); draw3DBox(0.0f, -5.0f, 0.0f, 10.0f, 0.2f, 10.0f); // Floor
    glColor3f(0.25f, 0.15f, 0.08f); draw3DBox(0.0f, -4.85f, -4.9f, 10.0f, 0.1f, 0.1f);
    glColor3f(0.70f, 0.66f, 0.56f);
    draw3DBox(-5.0f, 0.0f, 0.0f, 0.2f, 10.0f, 10.0f); draw3DBox(5.0f, 0.0f, 0.0f, 0.2f, 10.0f, 10.0f);

    glColor3f(0.52f, 0.24f, 0.05f);
    glBegin(GL_QUADS);
    glNormal3f(-0.707f, 0.707f, 0.0f);
    glVertex3f(-5.1f, 5.0f, -5.1f);   glVertex3f(0.0f, 7.6f, -5.1f);
    glVertex3f(0.0f, 7.6f, 5.1f);      glVertex3f(-5.1f, 5.0f, 5.1f);
    glNormal3f(0.707f, 0.707f, 0.0f);
    glVertex3f(5.1f, 5.0f, -5.1f);    glVertex3f(0.0f, 7.6f, -5.1f);
    glVertex3f(0.0f, 7.6f, 5.1f);     glVertex3f(5.1f, 5.0f, 5.1f);
    glEnd();

    glColor3f(0.74f, 0.70f, 0.60f);
    glBegin(GL_TRIANGLES); glNormal3f(0.0f, 0.0f, 1.0f);
    glVertex3f(-5.0f, 5.0f, -4.9f);   glVertex3f(5.0f, 5.0f, -4.9f);   glVertex3f(0.0f, 7.5f, -4.9f);
    glEnd();

    glPushMatrix(); glTranslatef(0.0f, 4.0f, -1.0f); glColor3f(0.2f, 0.2f, 0.2f);
    draw3DBox(0.0f, 0.4f, 0.0f, 0.05f, 0.6f, 0.05f); draw3DSphere(0.0f, 0.0f, 0.0f, 0.15f);
    glRotatef(fanAngle, 0.0f, 1.0f, 0.0f); glColor3f(0.3f, 0.3f, 0.3f);
    draw3DBox(0.7f, 0.0f, 0.0f, 1.2f, 0.02f, 0.15f); draw3DBox(-0.7f, 0.0f, 0.0f, 1.2f, 0.02f, 0.15f);
    draw3DBox(0.0f, 0.0f, 0.7f, 0.15f, 0.02f, 1.2f); glPopMatrix();

    glColor3f(0.22f, 0.10f, 0.02f);
    draw3DBox(0.0f, 2.0f, -4.9f, 4.2f, 0.15f, 0.3f);  draw3DBox(0.0f, -2.0f, -4.9f, 4.2f, 0.15f, 0.3f);
    draw3DBox(-2.0f, 0.0f, -4.9f, 0.15f, 4.0f, 0.3f); draw3DBox(2.0f, 0.0f, -4.9f, 0.15f, 4.0f, 0.3f);

    float panelShift = windowOpenFactor * 1.8f;
    glColor3f(0.42f, 0.21f, 0.06f); draw3DBox(-1.0f - panelShift, 0.0f, -4.8f, 1.9f, 3.8f, 0.1f);
    glColor3f(0.22f, 0.10f, 0.02f); draw3DBox(-1.0f - panelShift, 0.0f, -4.74f, 1.6f, 3.5f, 0.02f);
    glColor3f(0.42f, 0.21f, 0.06f); draw3DBox(1.0f + panelShift, 0.0f, -4.8f, 1.9f, 3.8f, 0.1f);
    glColor3f(0.22f, 0.10f, 0.02f); draw3DBox(1.0f + panelShift, 0.0f, -4.74f, 1.6f, 3.5f, 0.02f);
}

void display() {
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    glLoadIdentity();
    gluLookAt(camX, camY, camZ, camX, camY, -5.0f, 0.0f, 1.0f, 0.0f);
    glPushMatrix();
    glScalef(scaleFactor, scaleFactor, scaleFactor);
    glRotatef(rotX, 1.0f, 0.0f, 0.0f); glRotatef(rotY, 0.0f, 1.0f, 0.0f); glRotatef(rotZ, 0.0f, 0.0f, 1.0f);
    drawOutdoorEnvironment();
    draw3DRoom();
    glPopMatrix();
    glutSwapBuffers();
}

void timer(int value) {
    fanAngle += 8.0f; if (fanAngle > 360.0f) fanAngle -= 360.0f;
    birdFloat += 0.05f;
    if (isWindowOpen && windowOpenFactor < 1.0f) {
        windowOpenFactor += 0.0035f; if (windowOpenFactor > 1.0f) windowOpenFactor = 1.0f;
    } else if (!isWindowOpen && windowOpenFactor > 0.0f) {
        windowOpenFactor -= 0.0035f; if (windowOpenFactor < 0.0f) windowOpenFactor = 0.0f;
    }
    sunY = -3.0f + (windowOpenFactor * 7.5f); sunX = -4.0f + (windowOpenFactor * 3.0f);
    skyR = 0.05f + (windowOpenFactor * 0.35f); skyG = 0.05f + (windowOpenFactor * 0.65f); skyB = 0.15f + (windowOpenFactor * 0.80f);

    birdX += 0.04f;

    if (birdX > -6.0f && !birdChirped)
    {
        playBirdSoundAsync();
        birdChirped = true;
    }
    if (birdX > 8.0f)
    {
        birdX = -7.0f;
        birdChirped = false;
    }
    if (wingUp) { birdWingY += 0.02f; if (birdWingY > 0.1f) wingUp = false; }
    else { birdWingY -= 0.02f; if (birdWingY < -0.1f) wingUp = true; }

    alertFrameTimer++;
    if (alertFrameTimer % 20 == 0) alertLightOn = !alertLightOn;

    switch(carState) {
        case 0:
            carX += 0.06f;
            if (carX >= 0.0f) { carX = 0.0f; carState = 1; }
            break;

        case 1:
            carDoorShift += 0.015f;
            if (carDoorShift >= 0.35f) { carDoorShift = 0.35f; carWaitCounter = 0; carState = 2; }
            break;

        case 2:
            carWaitCounter++;
            if (carWaitCounter >= 90) carState = 3;
            break;

        case 3:
            carDoorShift -= 0.015f;
            if (carDoorShift <= 0.0f) {
                carDoorShift = 0.0f;
                playHornAsync();
                carState = 4;
            }
            break;

        case 4:
            carX += 0.06f;
            if (carX > 8.0f) { carX = -8.0f; carState = 0; }
            break;
    }

    if (swayRight) { treeSway += 0.003f; if (treeSway > 0.05f) swayRight = false; }
    else { treeSway -= 0.003f; if (treeSway < -0.05f) swayRight = true; }

    glutPostRedisplay();
    glutTimerFunc(16, timer, 0);
}

void keyboard(unsigned char key, int x, int y) {
    if (key == 'o' || key == 'O') isWindowOpen = true;
    if (key == 'c' || key == 'C') isWindowOpen = false;
    if (key == '+' || key == '=') scaleFactor += 0.05f;
    if (key == '-' || key == '_') scaleFactor -= 0.05f;
    if (key == 'x') rotX += 5.0f; if (key == 'X') rotX -= 5.0f;
    if (key == 'y') rotY += 5.0f; if (key == 'Y') rotY -= 5.0f;
    if (key == 'z') rotZ += 5.0f; if (key == 'Z') rotZ -= 5.0f;
    if (key == 'r' || key == 'R') { camX = 0.0f; camY = 0.5f; camZ = 4.2f; rotX = 0.0f; rotY = 0.0f; rotZ = 0.0f; scaleFactor = 1.0f; }
    glutPostRedisplay();
}

void specialKeys(int key, int x, int y) {
    switch (key) {
        case GLUT_KEY_LEFT:  camX -= 0.08f; break;
        case GLUT_KEY_RIGHT: camX += 0.08f; break;
        case GLUT_KEY_UP:    camY += 0.08f; break;
        case GLUT_KEY_DOWN:  camY -= 0.08f; break;
    }
    glutPostRedisplay();
}

void reshape(int w, int h) {
    if (h == 0) h = 1;
    glViewport(0, 0, w, h);
    glMatrixMode(GL_PROJECTION); glLoadIdentity();
    gluPerspective(60.0f, (float)w / (float)h, 0.1f, 100.0f);
    glMatrixMode(GL_MODELVIEW);
}

void initLighting() {
    glEnable(GL_DEPTH_TEST); glEnable(GL_LIGHTING); glEnable(GL_LIGHT0); glEnable(GL_COLOR_MATERIAL);
    GLfloat lightPos[] = { 0.0f, 5.0f, -2.0f, 1.0f }; GLfloat ambientLight[] = { 0.5f, 0.5f, 0.5f, 1.0f };
    glLightfv(GL_LIGHT0, GL_POSITION, lightPos); glLightfv(GL_LIGHT0, GL_AMBIENT, ambientLight);
}

int main(int argc, char** argv) {
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);
    glutInitWindowSize(900, 650); glutInitWindowPosition(100, 100);
    glutCreateWindow("Dynamic Scenario from Window.!!");
    glClearColor(0.05f, 0.05f, 0.05f, 1.0f);
    initLighting();
    glutDisplayFunc(display);   glutReshapeFunc(reshape);
    glutKeyboardFunc(keyboard); glutSpecialFunc(specialKeys);
    glutTimerFunc(0, timer, 0);
    glutMainLoop();
    return 0;
}

