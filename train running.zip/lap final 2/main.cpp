#ifdef _WIN32
#include <windows.h>
#endif
#include <GL/glut.h>
#include <iostream>
#include <cmath>

// State variables
float trainX = -15.0f;
bool trainMoving = true;
float doorOffset = 0.0f;
bool doorOpening = false;
bool doorClosing = false;

float carX = 0.0f, carZ = 5.0f;
bool isDay = true;
bool lightOn = false;

int cameraAngle = 1; // 1: Default, 2: Top, 3: Side

// Colors
float skyColorDay[] = {0.529f, 0.808f, 0.922f};
float skyColorNight[] = {0.05f, 0.05f, 0.2f};

void drawCube(float w, float h, float d) {
    glPushMatrix();
    glScalef(w, h, d);
    glutSolidCube(1.0);
    glPopMatrix();
}

void drawSphere(float r) {
    glutSolidSphere(r, 20, 20);
}

void setupLighting() {
    if (isDay) {
        glDisable(GL_LIGHTING);
        glClearColor(skyColorDay[0], skyColorDay[1], skyColorDay[2], 1.0);
    } else {
        glEnable(GL_LIGHTING);
        glEnable(GL_LIGHT0);
        glClearColor(skyColorNight[0], skyColorNight[1], skyColorNight[2], 1.0);

        GLfloat lightPos[] = {0.0, 10.0, 0.0, 1.0};
        GLfloat ambient[] = {0.2, 0.2, 0.2, 1.0};
        GLfloat diffuse[] = {0.5, 0.5, 0.5, 1.0};

        if (lightOn) {
            diffuse[0] = 1.0; diffuse[1] = 1.0; diffuse[2] = 0.8;
        }

        glLightfv(GL_LIGHT0, GL_POSITION, lightPos);
        glLightfv(GL_LIGHT0, GL_AMBIENT, ambient);
        glLightfv(GL_LIGHT0, GL_DIFFUSE, diffuse);
    }
}

void drawScene() {
    // Road
    glColor3f(0.2f, 0.2f, 0.2f);
    glPushMatrix();
    glTranslatef(0, -1.1, 5);
    drawCube(40, 0.2, 10);
    glPopMatrix();

    // Road Markings
    glColor3f(1, 1, 1);
    for(int i=-15; i<=15; i+=5) {
        glPushMatrix();
        glTranslatef(i, -1.05, 5);
        drawCube(2, 0.01, 0.2);
        glPopMatrix();
    }

    // Elevated Track
    glColor3f(0.4, 0.4, 0.4);
    glPushMatrix();
    glTranslatef(0, 3, 0);
    drawCube(40, 0.5, 4);
    glPopMatrix();

    // Pillars
    for(int i=-10; i<=10; i+=10) {
        glPushMatrix();
        glTranslatef(i, 1, 0);
        drawCube(1, 4, 1);
        glPopMatrix();
    }

    // Train
    glPushMatrix();
    glTranslatef(trainX, 4, 0);
    glColor3f(0.8, 0.8, 0.8); // Silver body
    drawCube(6, 2, 2.5);

    // Train Door
    glColor3f(0.2, 0.4, 0.8); // Blue door
    glPushMatrix();
    glTranslatef(0, 0, 1.26 + doorOffset);
    drawCube(1.5, 1.8, 0.1);
    glPopMatrix();

    // Train Windows
    glColor3f(0.1, 0.1, 0.1);
    glPushMatrix(); glTranslatef(-2, 0.3, 1.26); drawCube(1, 0.8, 0.1); glPopMatrix();
    glPushMatrix(); glTranslatef(2, 0.3, 1.26); drawCube(1, 0.8, 0.1); glPopMatrix();
    glPopMatrix();

    // Car
    glPushMatrix();
    glTranslatef(carX, -0.5, carZ);
    glColor3f(0.8, 0.1, 0.1); // Red car
    drawCube(2, 1, 1.2);
    // Car Windows
    glColor3f(0.6, 0.8, 1.0);
    glPushMatrix(); glTranslatef(0, 0.4, 0); drawCube(1.2, 0.5, 1.3); glPopMatrix();
    glPopMatrix();

    // Building
    glColor3f(0.3, 0.3, 0.3);
    glPushMatrix();
    glTranslatef(10, 4, -5);
    drawCube(8, 10, 8);
    glPopMatrix();

    // Sun/Moon
    if (isDay) {
        glColor3f(1, 1, 0);
        glPushMatrix();
        glTranslatef(15, 15, -10);
        drawSphere(2);
        glPopMatrix();
    }

    // Street Light
    glPushMatrix();
    glTranslatef(-5, 2, 8);
    glColor3f(0.2, 0.2, 0.2);
    drawCube(0.2, 6, 0.2); // Pole
    glTranslatef(0, 3, 0);
    if (lightOn) glColor3f(1, 1, 0.5);
    else glColor3f(0.1, 0.1, 0.1);
    drawSphere(0.5); // Bulb
    glPopMatrix();
}

void display() {
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    glLoadIdentity();

    // Camera control
    if (cameraAngle == 1) gluLookAt(0, 5, 20, 0, 2, 0, 0, 1, 0);
    else if (cameraAngle == 2) gluLookAt(0, 25, 1, 0, 0, 0, 0, 1, 0);
    else gluLookAt(20, 5, 5, 0, 2, 0, 0, 1, 0);

    setupLighting();
    drawScene();

    glutSwapBuffers();
}

void update(int value) {
    // Train animation
    if (trainMoving) {
        trainX += 0.1f;
        if (trainX >= 0.0f) {
            trainX = 0.0f;
            trainMoving = false;
        }
    }

    // Door animation
    if (doorOpening && doorOffset < 1.2f) doorOffset += 0.05f;
    if (doorClosing && doorOffset > 0.0f) doorOffset -= 0.05f;

    glutPostRedisplay();
    glutTimerFunc(16, update, 0);
}

void keyboard(unsigned char key, int x, int y) {
    switch (key) {
        case 'o': doorOpening = true; doorClosing = false; break;
        case 'c': doorClosing = true; doorOpening = false; break;
        case 't': isDay = !isDay; break;
        case 'l': lightOn = !lightOn; break;
        case '1': cameraAngle = 1; break;
        case '2': cameraAngle = 2; break;
        case '3': cameraAngle = 3; break;
        case 'w': carZ -= 0.2f; break;
        case 's': carZ += 0.2f; break;
        case 'a': carX -= 0.2f; break;
        case 'd': carX += 0.2f; break;
        case 27: exit(0); break;
    }
}

void reshape(int w, int h) {
    glViewport(0, 0, w, h);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluPerspective(45.0, (double)w / (double)h, 1.0, 200.0);
    glMatrixMode(GL_MODELVIEW);
}

int main(int argc, char** argv) {
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);
    glutInitWindowSize(800, 600);
    glutCreateWindow("3D Graphics Project - Train & Car");

    glEnable(GL_DEPTH_TEST);

    glutDisplayFunc(display);
    glutReshapeFunc(reshape);
    glutKeyboardFunc(keyboard);
    glutTimerFunc(16, update, 0);

    std::cout << "Controls:" << std::endl;
    std::cout << "o: Open Door | c: Close Door" << std::endl;
    std::cout << "t: Toggle Day/Night | l: Toggle Light" << std::endl;
    std::cout << "w/a/s/d: Move Car" << std::endl;
    std::cout << "1/2/3: Change Camera Angle" << std::endl;
    std::cout << "ESC: Exit" << std::endl;

    glutMainLoop();
    return 0;
}
