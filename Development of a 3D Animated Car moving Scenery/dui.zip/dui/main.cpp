 #include <windows.h>
#include <GL/glut.h>
#include <math.h>
#include <stdlib.h>

// ============================================================================
// --- গ্লোবাল ভ্যারিয়েবলস ও টেক্সচার ID ---
// ============================================================================
float c1z = 5.0f;  // লাল গাড়ির পজিশন
float c2z = 5.5f;  // নীল গাড়ির পজিশন
float cx = 0.0f;
float wave = 0.0f;

float camX = 0.0f;
float camY = 2.0f;
float camZ = 6.8f;

bool doorOpen = false;
bool showMan = true;
int timer = 0;

float manX = 1.45f;
float manY = 0.12f;
float manZ = 0.8f;

GLuint grassTexture;
GLuint roadTexture;

// ============================================================================
// --- প্রোসিডুরাল টেক্সচার জেনারেটর ---
// ============================================================================
void createProceduralTextures() {
    const int width = 64;
    const int height = 64;
    GLubyte grassData[width][height][3];
    GLubyte roadData[width][height][3];

    for (int i = 0; i < width; i++) {
        for (int j = 0; j < height; j++) {
            int noise = rand() % 20;
            grassData[i][j][0] = 75 + noise;
            grassData[i][j][1] = 180 + noise;
            grassData[i][j][2] = 45;

            int roadNoise = rand() % 15;
            roadData[i][j][0] = 55 + roadNoise;
            roadData[i][j][1] = 55 + roadNoise;
            roadData[i][j][2] = 55 + roadNoise;
        }
    }

    glGenTextures(1, &grassTexture);
    glBindTexture(GL_TEXTURE_2D, grassTexture);
    glTexParameteri(GL_TEXTURE_2D,
                    GL_TEXTURE_MAG_FILTER,
                    GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D,
                    GL_TEXTURE_MIN_FILTER,
                    GL_LINEAR);
    glTexImage2D(GL_TEXTURE_2D, 0,
                 GL_RGB, width,
                 height, 0,
                 GL_RGB,
                 GL_UNSIGNED_BYTE,
                 grassData);

    glGenTextures(1, &roadTexture);
    glBindTexture(GL_TEXTURE_2D, roadTexture);
    glTexParameteri(GL_TEXTURE_2D,
                    GL_TEXTURE_MAG_FILTER,
                    GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D,
                    GL_TEXTURE_MIN_FILTER,
                    GL_LINEAR);
    glTexImage2D(GL_TEXTURE_2D, 0,
                 GL_RGB, width, height, 0,
                 GL_RGB, GL_UNSIGNED_BYTE,
                 roadData);
}

float getCurve(float z) {
    float t = (z + 7.0f) / 14.0f;
    return sin(t * 3.14159f) * -0.28f;
}

// ============================================================================
// --- বেসিক থ্রিডি ড্রয়িং শেপস ---
// ============================================================================
void drawBox(float x,
             float y,
             float z,
             float sx,
             float sy,
             float sz,
             float r,
             float g,
             float b) {
    glColor3f(r, g, b);
    glPushMatrix();
    glTranslatef(x, y, z);
    glScalef(sx, sy, sz);
    glutSolidCube(1.0);
    glPopMatrix();
}

void drawBall(float x,
              float y,
              float z,
              float rad,
              float r,
              float g,
              float b,
              int slices = 10) {
    glColor3f(r, g, b);
    glPushMatrix();
    glTranslatef(x, y, z);
    glutSolidSphere(rad, slices, slices);
    glPopMatrix();
}

// ৩ডি সূর্যের জন্য গ্লোবাল লাইটিং ইফেক্ট ছাড়া থ্রিডি লুক দেওয়ার সহজ ফাংশন
void draw3DSun(float x,
               float y,
               float z,
               float rad,
               float r,
               float g,
               float b) {
    glPushMatrix();
    glTranslatef(x, y, z);

    // ৩ডি রিয়েলস্টিক শেডিং লুক দেওয়ার জন্য লেয়ারড স্ফিয়ার মেথড (সহজ ও লাইট ছাড়া কাজ করে)
    int totalLayers = 30;
    for (int i = 0; i < totalLayers; i++) {
        float factor = (float)i / totalLayers;
        // কেন্দ্র থেকে বাইরের দিকে হালকা থেকে গাঢ় শেড তৈরি করবে
        glColor3f(r, g - (factor * 0.25f), b);
        glutSolidSphere(rad * (1.0f - factor * 0.03f), 32, 32);
    }
    glPopMatrix();
}
 void cloud(float x, float y, float z, float scale) {
    glPushMatrix();
    glTranslatef(x, y, z);
    glScalef(scale, scale, scale);

    drawBall(-0.2f, 0.0f, 0.0f, 0.18f, 1.0f, 1.0f, 1.0f);
    drawBall(0.0f, 0.1f, 0.0f, 0.24f, 1.0f, 1.0f, 1.0f);
    drawBall(0.2f, 0.0f, 0.0f, 0.18f, 1.0f, 1.0f, 1.0f);

    glPopMatrix();
}

// ============================================================================
// --- পাথুরে পাহাড় ফাংশন ---
// ============================================================================
void rockyMountain(float x,
                   float y,
                   float z,
                   float scaleX,
                   float scaleY) {
    glPushMatrix();
    glTranslatef(x, y, z);
    glScalef(scaleX, scaleY, scaleX);

    glBegin(GL_TRIANGLES);
        // বাম পাশের ফেস
        glColor3f(0.72f, 0.70f, 0.65f);
        glVertex3f(0.0f, 2.0f, 0.0f);
        glColor3f(0.60f, 0.58f, 0.53f);
        glVertex3f(-1.2f, 0.0f, 0.8f);
        glVertex3f(0.0f, 0.0f, 1.2f);

        // মাঝখানের প্রধান চূড়া
        glColor3f(0.80f, 0.78f, 0.73f);
        glVertex3f(0.0f, 2.0f, 0.0f);
        glColor3f(0.68f, 0.66f, 0.61f);
        glVertex3f(0.0f, 0.0f, 1.2f);
        glVertex3f(1.0f, 0.0f, 0.8f);

        // ডান পাশের অন্ধকার ফেস
        glColor3f(0.52f, 0.50f, 0.46f);
        glVertex3f(0.0f, 2.0f, 0.0f);
        glVertex3f(1.0f, 0.0f, 0.8f);
        glColor3f(0.40f, 0.38f, 0.35f);
        glVertex3f(1.2f, 0.0f, -0.5f);

        // পেছনের সাপোর্ট ফেসসমূহ
        glColor3f(0.48f, 0.46f, 0.42f);
        glVertex3f(0.0f, 2.0f, 0.0f);
        glVertex3f(1.2f, 0.0f, -0.5f);
        glVertex3f(-1.2f, 0.0f, -0.5f);

        glColor3f(0.58f, 0.56f, 0.51f);
        glVertex3f(0.0f, 2.0f, 0.0f);
        glVertex3f(-1.2f, 0.0f, -0.5f);
        glVertex3f(-1.2f, 0.0f, 0.8f);
    glEnd();

    drawBall(-0.6f, 0.1f, 0.9f, 0.25f, 0.55f, 0.53f, 0.49f, 8);
    drawBall(0.7f, 0.12f, 0.8f, 0.3f, 0.48f, 0.46f, 0.42f, 8);

    glPopMatrix();
}

// ============================================================================
// --- পাইন গাছ ফাংশন ---
// ============================================================================
void pineTree(float x, float y, float z, float scale) {
    glPushMatrix();
    glTranslatef(x, y, z);
    glScalef(scale, scale, scale);

    drawBox(0.0f, 0.25f, 0.0f, 0.08f, 0.5f, 0.08f, 0.4f, 0.22f, 0.05f);

    glColor3f(0.12f, 0.42f, 0.18f);
    glPushMatrix();
        glTranslatef(0.0f, 0.45f, 0.0f);
        glRotatef(-90.0f, 1.0f, 0.0f, 0.0f);
        glutSolidCone(0.35, 0.5, 12, 1);
    glPopMatrix();

    glColor3f(0.10f, 0.38f, 0.15f);
    glPushMatrix();
        glTranslatef(0.0f, 0.75f, 0.0f);
        glRotatef(-90.0f, 1.0f, 0.0f, 0.0f);
        glutSolidCone(0.28, 0.45, 12, 1);
    glPopMatrix();

    glColor3f(0.08f, 0.35f, 0.12f);
    glPushMatrix();
        glTranslatef(0.0f, 1.05f, 0.0f);
        glRotatef(-90.0f, 1.0f, 0.0f, 0.0f);
        glutSolidCone(0.20, 0.4, 12, 1);
    glPopMatrix();

    glPopMatrix();
}

// ============================================================================
// --- কার এবং বোট ড্রয়িং ইঞ্জিন ---
// ============================================================================
void drawRealisticCar(float r, float g, float b) {
    glPushMatrix();

    drawBox(0.0f, 0.1f, 0.0f, 0.24f, 0.12f, 0.46f, r, g, b);
    drawBox(0.0f, 0.21f, -0.02f, 0.20f, 0.11f, 0.24f, r * 0.85f, g * 0.85f, b * 0.85f);
    drawBox(0.0f, 0.06f, 0.235f, 0.25f, 0.04f, 0.02f, 0.15f, 0.15f, 0.15f);
    drawBox(0.0f, 0.06f, -0.235f, 0.25f, 0.04f, 0.02f, 0.15f, 0.15f, 0.15f);
    drawBox(0.0f, 0.21f, 0.101f, 0.18f, 0.08f, 0.01f, 0.6f, 0.85f, 0.95f);
    drawBox(0.0f, 0.21f, -0.141f, 0.18f, 0.08f, 0.01f, 0.6f, 0.85f, 0.95f);

    float wX[4] = {-0.13f, -0.13f, 0.10f, 0.10f};
    float wZ[4] = {-0.12f, 0.12f, -0.12f, 0.12f};

    for (int i = 0; i < 4; i++) {
        glPushMatrix();
        glTranslatef(wX[i], 0.05f, wZ[i]);
        glColor3f(0.12f, 0.12f, 0.12f);

        glPushMatrix();
        glScalef(0.4f, 1.0f, 1.0f);
        glutSolidSphere(0.05, 12, 12);
        glPopMatrix();
 glColor3f(0.75f, 0.75f, 0.75f);
        glPushMatrix();
        glScalef(0.5f, 0.7f, 0.7f);
        glutSolidSphere(0.04, 10, 10);
        glPopMatrix();

        glPopMatrix();
    }
    glPopMatrix();
}

void draw3DBoat() {
    float r1 = 0.35f, g1 = 0.18f, b1 = 0.08f;
    float r2 = 0.25f, g2 = 0.12f, b2 = 0.05f;

    glBegin(GL_QUADS);
        glColor3f(r2, g2, b2);
        glVertex3f(-0.3f, 0.0f, -0.8f);
        glVertex3f(0.3f, 0.0f, -0.8f);
        glVertex3f(0.3f, 0.0f, 0.8f);
        glVertex3f(-0.3f, 0.0f, 0.8f);

        glColor3f(r1, g1, b1);
        glVertex3f(-0.3f, 0.0f, -0.8f);
        glVertex3f(-0.3f, 0.0f, 0.8f);
        glVertex3f(-0.5f, 0.3f, 0.8f);
        glVertex3f(-0.5f, 0.3f, -0.8f);

        glColor3f(r1, g1, b1);
        glVertex3f(0.3f, 0.0f, -0.8f);
        glVertex3f(0.3f, 0.0f, 0.8f);
        glVertex3f(0.5f, 0.3f, 0.8f);
        glVertex3f(0.5f, 0.3f, -0.8f);
    glEnd();

    glBegin(GL_TRIANGLES);
        glColor3f(r1 * 1.2f, g1 * 1.2f, b1 * 1.2f);
        glVertex3f(-0.5f, 0.3f, 0.8f);
        glVertex3f(0.5f, 0.3f, 0.8f);
        glVertex3f(0.0f, 0.35f, 1.3f);

        glColor3f(r1 * 0.9f, g1 * 0.9f, b1 * 0.9f);
        glVertex3f(-0.5f, 0.3f, -0.8f);
        glVertex3f(0.5f, 0.3f, -0.8f);
        glVertex3f(0.0f, 0.35f, -1.3f);
    glEnd();

    drawBox(0.0f, 0.5f, 0.2f, 0.03f, 1.1f, 0.03f, 0.2f, 0.1f, 0.0f);

    glBegin(GL_TRIANGLES);
        glColor3f(0.95f, 0.95f, 0.95f);
        glVertex3f(0.0f, 1.6f, 0.2f);
        glVertex3f(-0.5f, 0.5f, 0.2f);
        glVertex3f(0.5f, 0.4f, 0.2f);
    glEnd();
}

void drawMan(float x, float y, float z) {
    glPushMatrix();
    glTranslatef(x, y, z);
    glScalef(0.45f, 0.45f, 0.45f);

    drawBox(0.0f, 0.2f, 0.0f, 0.08f, 0.18f, 0.08f, 0.8f, 0.2f, 0.2f);
    drawBall(0.0f, 0.33f, 0.0f, 0.045f, 0.9f, 0.7f, 0.5f);
    drawBox(-0.022f, 0.06f, 0.0f, 0.02f, 0.12f, 0.02f, 0.1f, 0.1f, 0.3f);
    drawBox( 0.022f, 0.06f, 0.0f, 0.02f, 0.12f, 0.02f, 0.1f, 0.1f, 0.3f);

    glPopMatrix();
}

// ============================================================================
// --- প্রধান গ্রাফিক্স রেন্ডারিং ডিসপ্লে ---
// ============================================================================
void display() {
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    glLoadIdentity();
    gluLookAt(camX, camY, camZ,  0.0f, 0.2f, -3.0f,  0.0f, 1.0f, 0.0f);

    // ১. ব্যাকগ্রাউন্ড ঘাস
    glEnable(GL_TEXTURE_2D);
    glBindTexture(GL_TEXTURE_2D, grassTexture);
    glColor3f(1.0f, 1.0f, 1.0f);
    glBegin(GL_QUADS);
        glTexCoord2f(0.0f, 0.0f);
        glVertex3f(-100.0f, 0.0f, -100.0f);
        glTexCoord2f(25.0f, 0.0f);
        glVertex3f(100.0f, 0.0f, -100.0f);
        glTexCoord2f(25.0f, 25.0f);
        glVertex3f(100.0f, 0.0f, 100.0f);
        glTexCoord2f(0.0f, 25.0f);
        glVertex3f(-100.0f, 0.0f, 100.0f);
    glEnd();
    glDisable(GL_TEXTURE_2D);

    // নদী ও রিয়েলিস্টিক ঢেউ
    glBegin(GL_QUADS);
        glColor3f(0.22f, 0.58f, 0.92f);
        glVertex3f(0.42f, 0.001f, -7.0f);
        glVertex3f(100.0f, 0.001f, -7.0f);
        glVertex3f(100.0f, 0.001f, 7.0f);
        glVertex3f(2.05f, 0.001f, 7.0f);
    glEnd();

    // অ্যানিমেটেড ঢেউ মেকার লাইন
    glColor3f(0.45f, 0.78f, 1.0f);
    glLineWidth(1.5f);
    for (float z = -7.0f; z <= 7.0f; z += 0.4f) {
        glBegin(GL_LINE_STRIP);
        float startX = 0.42f + ((z - (-7.0f)) / 14.0f) * (2.05f - 0.42f) + 0.15f;
        for (float x = startX; x <= 12.0f; x += 0.2f) {
            float waveY = 0.006f + 0.012f * sin(x * 6.0f + z * 3.0f + wave);
            glVertex3f(x, waveY, z);
        }
        glEnd();
    }
 // ২. বক্র রাস্তা
    glEnable(GL_TEXTURE_2D);
    glBindTexture(GL_TEXTURE_2D, roadTexture);
    glColor3f(1.0f, 1.0f, 1.0f);
    glBegin(GL_QUADS);
    for (float z = -7.0f; z < 7.0f; z += 0.1f) {
        float z1 = z; float z2 = z + 0.1f;
        float t1 = (z1 - (-7.0f)) / 14.0f; float t2 = (z2 - (-7.0f)) / 14.0f;
        float w1 = 0.4f + t1 * 1.6f; float w2 = 0.4f + t2 * 1.6f;
        float offset1 = getCurve(z1); float offset2 = getCurve(z2);
        float v1 = (z1 + 7.0f) / 14.0f; float v2 = (z2 + 7.0f) / 14.0f;

        glTexCoord2f(0.0f, v1);
        glVertex3f(offset1 - w1, 0.001f, z1);
        glTexCoord2f(1.0f, v1);
        glVertex3f(offset1 + w1, 0.001f, z1);
        glTexCoord2f(1.0f, v2);
        glVertex3f(offset2 + w2, 0.001f, z2);
        glTexCoord2f(0.0f, v2);
        glVertex3f(offset2 - w2, 0.001f, z2);
    }
    glEnd();
    glDisable(GL_TEXTURE_2D);

    // হলুদ ডিভাইডার
    glBegin(GL_QUADS);
    for (float z = -7.0f; z < 7.0f; z += 0.1f) {
        float z1 = z; float z2 = z + 0.1f;
        float t1 = (z1 - (-7.0f)) / 14.0f; float t2 = (z2 - (-7.0f)) / 14.0f;
        float offset1 = getCurve(z1); float offset2 = getCurve(z2);
        float cw1 = 0.015f + t1 * 0.02f; float cw2 = 0.015f + t2 * 0.02f;
        glColor3f(1.0f, 0.78f, 0.0f);
        glVertex3f(offset1 - cw1, 0.003f, z1);
        glVertex3f(offset1 + cw1, 0.003f, z1);
        glVertex3f(offset2 + cw2, 0.003f, z2);
        glVertex3f(offset2 - cw2, 0.003f, z2);
    }
    glEnd();

    // সূর্য ও মেঘ (এখানে সূর্যকে ৩ডি ফাংশন দিয়ে পরিবর্তন করা হয়েছে)
    draw3DSun(0.5f, 4.5f, -15.0f, 0.35f, 1.0f, 0.88f, 0.1f);

    cloud(cx, 3.5f, -5.0f, 1.0f);
    cloud(-2.5f, 3.7f, -6.0f, 0.8f);
    cloud(3.0f, 3.6f, -5.5f, 1.1f);

    // ৩. ছড়ানো পাথুরে পাহাড় বিন্যাস
    rockyMountain(-6.5f, 0.0f, -8.0f, 2.2f, 1.3f);
    rockyMountain(-4.2f, 0.0f, -7.5f, 1.9f, 1.1f);
    rockyMountain(-2.0f, 0.0f, -7.0f, 1.6f, 0.9f);
    rockyMountain(1.5f, 0.0f, -7.5f, 1.8f, 1.1f);
    rockyMountain(4.0f, 0.0f, -8.0f, 2.3f, 1.4f);
    rockyMountain(6.8f, 0.0f, -8.5f, 2.0f, 1.2f);

    rockyMountain(-4.8f, 0.0f, -11.0f, 4.0f, 2.5f);
    rockyMountain(3.5f, 0.0f, -11.5f, 3.8f, 2.3f);

    // ৪. পাহাড়ের ফাঁকে ফাঁকে গাছ বসানো
    pineTree(-5.3f, 0.0f, -7.8f, 0.50f);
    pineTree(-3.1f, 0.0f, -7.2f, 0.45f);
    pineTree(-0.5f, 0.0f, -7.3f, 0.40f);
    pineTree(2.8f, 0.0f, -7.8f, 0.48f);
    pineTree(5.3f, 0.0f, -8.1f, 0.52f);
    pineTree(-5.5f, 1.2f, -8.5f, 0.35f);
    pineTree(4.2f, 1.0f, -8.3f, 0.38f);

    // ৫. রাস্তার পাশে সারিবদ্ধ পাইন গাছ
    pineTree(-1.1f, 0.0f, -5.5f, 0.40f);
    pineTree(-1.2f, 0.0f, -4.0f, 0.45f);
    pineTree(-1.3f, 0.0f, -2.5f, 0.50f);
    pineTree(-1.4f, 0.0f, -1.0f, 0.55f);
    pineTree(-1.5f, 0.0f,  0.5f, 0.60f);
    pineTree(-1.7f, 0.0f,  2.0f, 0.68f);
    pineTree(-1.9f, 0.0f,  3.5f, 0.75f);
    pineTree(-2.1f, 0.0f,  5.0f, 0.82f);
    pineTree(-2.3f, 0.0f,  6.5f, 0.90f);

    // নদীর নৌকা
    glPushMatrix();
        glTranslatef(1.6f, 0.02f, 0.8f);
        glRotatef(22.0f, 0.0f, 1.0f, 0.0f);
        glScalef(0.3f, 0.3f, 0.4f);
        draw3DBoat();
    glPopMatrix();

    // ৬. ট্রাফিক অবজেক্টস (লাল গাড়ি কিবোর্ড দ্বারা নিয়ন্ত্রিত)
    glPushMatrix();
        float t1_c = (c1z - (-7.0f)) / 14.0f; float w1_c = 0.4f + t1_c * 1.6f;
        float c1X = getCurve(c1z) - w1_c * 0.45f;
        glTranslatef(c1X, 0.0f, c1z);
        glRotatef(180.0f, 0.0f, 1.0f, 0.0f);
        drawRealisticCar(0.85f, 0.08f, 0.08f);
    glPopMatrix();

    glPushMatrix();
        float t2_c = (c2z - (-7.0f)) / 14.0f; float w2_c = 0.4f + t2_c * 1.6f;
        float c2X = getCurve(c2z) + w2_c * 0.45f;
        glTranslatef(c2X, 0.0f, c2z);
        glRotatef(180.0f, 0.0f, 1.0f, 0.0f);
        drawRealisticCar(0.12f, 0.35f, 0.85f);

        glPushMatrix();
            glTranslatef(-0.12f, 0.15f, 0.0f);
            if (doorOpen) glRotatef(-75.0f, 0.0f, 1.0f, 0.0f);
            drawBox(0.0f, 0.0f, 0.0f, 0.015f, 0.11f, 0.16f, 0.08f, 0.25f, 0.65f);
        glPopMatrix();
    glPopMatrix();

    if (showMan) drawMan(manX, manY, manZ);

    glutSwapBuffers();
}
 void reshape(int w, int h) {
    if (h == 0) h = 1;
    glViewport(0, 0, w, h);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluPerspective(60.0f, (GLfloat)w / (GLfloat)h, 0.1f, 1000.0f);
    glMatrixMode(GL_MODELVIEW);
}

void init() {
    glEnable(GL_DEPTH_TEST);
    glClearColor(0.50f, 0.78f, 1.0f, 1.0f);
    createProceduralTextures();
}

// ============================================================================
// --- আপনার স্পেশাল কিবোর্ড ইন্টারঅ্যাকশন ফাংশন ---
// ============================================================================
void handleSpecialKeys(int key, int x, int y) {
    switch (key) {
        case GLUT_KEY_LEFT:  camX -= 0.15f; break;
        case GLUT_KEY_RIGHT: camX += 0.15f; break;
        case GLUT_KEY_UP:    camZ -= 0.2f;  break;
        case GLUT_KEY_DOWN:  camZ += 0.2f;  break;

        // F2 এবং F3 দিয়ে লাল গাড়ির মুভমেন্ট (Z-axis)
        case GLUT_KEY_F2:    c1z -= 0.15f;  break; // গাড়ি সামনে যাবে
        case GLUT_KEY_F3:    c1z += 0.15f;  break; // গাড়ি পেছনে আসবে

        // F6 এবং F7 দিয়ে ক্যামেরার উচ্চতা পরিবর্তন (Up/Down)
        case GLUT_KEY_F6:    camY += 0.1f;  break; // kamera upore uthbe
        case GLUT_KEY_F7:    if(camY > 0.2f) camY -= 0.1f; break; // kamera niche nambe
    }
    glutPostRedisplay();
}

void update(int value) {
    cx += 0.003f; if (cx > 5.0f) cx = -5.0f;
    wave += 0.08f;

    // নীল গাড়ির অ্যানিমেশন লুপ
    if (c2z <= 1.2f && c2z >= 1.05f) {
        timer++;
        if (timer <= 30) { doorOpen = false; showMan = true; manY = 0.12f; }
        else if (timer > 30 && timer <= 200) {
            doorOpen = true; manY = 0.02f;
            float t2_c = (c2z - (-7.0f)) / 14.0f; float w2_c = 0.4f + t2_c * 1.6f;
            float targetCarX = getCurve(c2z) + w2_c * 0.45f - 0.01f;
            if (manX > targetCarX) manX -= 0.009f;
            if (manZ > c2z) manZ -= 0.001f;
        }
        else if (timer > 200 && timer <= 240) { showMan = false; doorOpen = false; }
        else { c2z -= 0.04f; }
    }
    else {
        c2z -= 0.04f; timer = 0; showMan = true;
        float t_man = (0.8f - (-7.0f)) /
         14.0f; float w_man = 0.4f + t_man * 1.6f;
        manX = getCurve(0.8f) + w_man + 0.15f; manY = 0.12f; manZ = 0.8f;
    }
    if (c2z < -6.8f) c2z = 5.5f;

    glutPostRedisplay();
    glutTimerFunc(16, update, 0);
}

int main(int argc, char** argv) {
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);
    glutInitWindowSize(800, 600);
    glutInitWindowPosition(100, 100);
    glutCreateWindow("3D Scenery - 3D Sun Added");

    init();
    glutDisplayFunc(display);
    glutReshapeFunc(reshape);
    glutSpecialFunc(handleSpecialKeys);
    glutTimerFunc(16, update, 0);

    glutMainLoop();
    return 0;
}
